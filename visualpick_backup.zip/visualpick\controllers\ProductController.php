<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Auth;
use Admin\Core\Database;

class ProductController extends Controller {
    public function index() {
        Auth::enforce('product', 'view');
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN category c ON p.category_id = c.id ORDER BY p.id DESC");
        $products = $stmt->fetchAll();
        
        $this->view('products.index', [
            'pageTitle' => 'Quản lý Sản Phẩm',
            'products' => $products
        ]);
    }

    public function create() {
        Auth::enforce('product', 'create');
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT * FROM category ORDER BY name ASC");
        $categories = $stmt->fetchAll();
        
        $this->view('products.create', [
            'pageTitle' => 'Thêm Sản Phẩm',
            'categories' => $categories
        ]);
    }

    public function store() {
        Auth::enforce('product', 'create');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $price = !empty($_POST['price']) ? (float)str_replace('.', '', $_POST['price']) : 0;
            $discount = !empty($_POST['discount']) ? (float)str_replace('.', '', $_POST['discount']) : 0;
            $image_url = $_POST['image_url'];
            $description = $_POST['description'];
            $categoryId = $_POST['category_id'];
            
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("INSERT INTO products (name, price, discount, image_url, description, category_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->execute([$name, $price, $discount, $image_url, $description, $categoryId]);
            
            $productId = $db->lastInsertId();
            \Admin\Core\ActivityLogger::log('create', 'Product', $productId, "Created product: $name");
            
            $this->redirect('/products');
        }
    }

    public function edit($id) {
        Auth::enforce('product', 'edit');
        
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            die("Product not found");
        }
        
        $stmt = $db->query("SELECT * FROM category ORDER BY name ASC");
        $categories = $stmt->fetchAll();
        
        $this->view('products.edit', [
            'pageTitle' => 'Sửa Sản Phẩm',
            'product' => $product,
            'categories' => $categories
        ]);
    }

    public function update($id) {
        Auth::enforce('product', 'edit');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'];
            $price = !empty($_POST['price']) ? (float)str_replace('.', '', $_POST['price']) : 0;
            $discount = !empty($_POST['discount']) ? (float)str_replace('.', '', $_POST['discount']) : 0;
            $image_url = $_POST['image_url'];
            $description = $_POST['description'];
            $categoryId = $_POST['category_id'];
            
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE products SET name = ?, price = ?, discount = ?, image_url = ?, description = ?, category_id = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$name, $price, $discount, $image_url, $description, $categoryId, $id]);
            
            \Admin\Core\ActivityLogger::log('update', 'Product', $id, "Updated product: $name");
            
            $this->redirect('/products');
        }
    }

    public function delete($id) {
        Auth::enforce('product', 'delete');
        
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT name FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $name = $stmt->fetchColumn();
        
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        \Admin\Core\ActivityLogger::log('delete', 'Product', $id, "Deleted product: $name");
        
        $this->redirect('/products');
    }
}

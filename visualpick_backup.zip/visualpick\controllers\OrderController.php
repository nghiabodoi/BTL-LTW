<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Auth;

class OrderController extends Controller {
    public function index() {
        Auth::enforce('order', 'view');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        $stmt = $db->query("SELECT * FROM orders ORDER BY order_date DESC");
        $orders = $stmt->fetchAll();
        
        $this->view('orders.index', [
            'pageTitle' => 'Orders Management',
            'orders' => $orders
        ]);
    }

    public function show($id) {
        Auth::enforce('order', 'view');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        // Fetch order details
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        
        if (!$order) {
            die("Order not found");
        }
        
        // Fetch order items
        $stmt = $db->prepare("
            SELECT od.*, p.name as product_name, p.image_url 
            FROM order_details od 
            LEFT JOIN products p ON od.product_id = p.id 
            WHERE od.order_id = ?
        ");
        $stmt->execute([$id]);
        $items = $stmt->fetchAll();
        
        $this->view('orders.show', [
            'pageTitle' => 'Order Details #' . $id,
            'order' => $order,
            'items' => $items
        ]);
    }

    public function updateStatus($id) {
        Auth::enforce('order', 'edit');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $status = $_POST['status'];
            
            $db = \Admin\Core\Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            
            \Admin\Core\ActivityLogger::log('update', 'Order', $id, "Updated order status to: $status");
            
            $this->redirect('/orders/show/' . $id);
        }
    }

    public function delete($id) {
        Auth::enforce('order', 'delete');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        
        \Admin\Core\ActivityLogger::log('delete', 'Order', $id, "Deleted order #$id");
        
        $this->redirect('/orders');
    }
}

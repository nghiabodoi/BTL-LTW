<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Auth;
use Admin\Core\Database;

class DashboardController extends Controller {
    public function index() {
        Auth::enforce('dashboard', 'view'); // User needs view_dashboard permission or be Super Admin

        $db = Database::getInstance()->getConnection();
        
        // Fetch some basic stats
        $usersCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $ordersCount = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $productsCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
        
        // Recent Orders
        $recentOrders = $db->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 5")->fetchAll();
        
        // Revenue for last 6 months
        $revenueData = $db->query("
            SELECT DATE_FORMAT(order_date, '%b') as month_name, SUM(total_money) as revenue 
            FROM orders 
            WHERE status = 'delivered' AND order_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
            GROUP BY DATE_FORMAT(order_date, '%Y-%m'), DATE_FORMAT(order_date, '%b') 
            ORDER BY DATE_FORMAT(order_date, '%Y-%m') ASC
        ")->fetchAll(\PDO::FETCH_ASSOC);

        // Order Status Distribution
        $statusData = $db->query("
            SELECT status, COUNT(*) as count 
            FROM orders 
            GROUP BY status
        ")->fetchAll(\PDO::FETCH_ASSOC);
        
        $this->view('dashboard.index', [
            'pageTitle' => 'Bảng điều khiển',
            'usersCount' => $usersCount,
            'ordersCount' => $ordersCount,
            'productsCount' => $productsCount,
            'recentOrders' => $recentOrders,
            'revenueData' => $revenueData,
            'statusData' => $statusData
        ]);
    }
}

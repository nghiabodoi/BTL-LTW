<?php
session_start();

// Autoloader for Admin classes
spl_autoload_register(function ($class) {
    $prefix = 'Admin\\';
    $base_dir = __DIR__ . '/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

use Admin\Core\Router;

$scriptName = $_SERVER['SCRIPT_NAME'];
$basePath = dirname($scriptName);
$basePath = rtrim(str_replace('\\', '/', $basePath), '/');
define('BASE_URL', $basePath);

$router = new Router();

// Dashboard
$router->get('/', 'DashboardController@index');
$router->get('/dashboard', 'DashboardController@index');

// Auth
$router->get('/login', 'AuthController@loginForm');
$router->post('/login', 'AuthController@login');
$router->get('/logout', 'AuthController@logout');

// Products
$router->get('/products', 'ProductController@index');
$router->get('/products/create', 'ProductController@create');
$router->post('/products/store', 'ProductController@store');
$router->get('/products/edit/{id}', 'ProductController@edit');
$router->post('/products/update/{id}', 'ProductController@update');
$router->post('/products/delete/{id}', 'ProductController@delete');

// Orders
$router->get('/orders', 'OrderController@index');
$router->get('/orders/show/{id}', 'OrderController@show');
$router->post('/orders/update_status/{id}', 'OrderController@updateStatus');
$router->post('/orders/delete/{id}', 'OrderController@delete');

// Users
$router->get('/users', 'UserController@index');
$router->get('/users/create', 'UserController@create');
$router->post('/users/store', 'UserController@store');
$router->get('/users/edit/{id}', 'UserController@edit');
$router->post('/users/update/{id}', 'UserController@update');
$router->post('/users/delete/{id}', 'UserController@delete');

// Tickets
$router->get('/tickets', 'TicketController@index');
$router->get('/tickets/show/{id}', 'TicketController@show');
$router->post('/tickets/reply/{id}', 'TicketController@reply');
$router->post('/tickets/update_status/{id}', 'TicketController@updateStatus');

// Run the router
$url = $_SERVER['REQUEST_URI'];
if (($pos = strpos($url, '?')) !== false) {
    $url = substr($url, 0, $pos);
}

if ($basePath !== '' && strpos($url, $basePath) === 0) {
    $url = substr($url, strlen($basePath));
}

$router->dispatch($url, $_SERVER['REQUEST_METHOD']);
<?php
namespace Admin\Core;

class Router {
    private $routes = [];

    public function add($method, $route, $controllerAction) {
        // Convert route like '/products/edit/{id}' to regex
        $route = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<\1>[a-zA-Z0-9_-]+)', $route);
        $route = "#^" . $route . "$#";
        
        $this->routes[] = [
            'method' => strtoupper($method),
            'route' => $route,
            'controllerAction' => $controllerAction
        ];
    }

    public function get($route, $controllerAction) {
        $this->add('GET', $route, $controllerAction);
    }

    public function post($route, $controllerAction) {
        $this->add('POST', $route, $controllerAction);
    }

    public function dispatch($url, $requestMethod) {
        $url = parse_url($url, PHP_URL_PATH);
        
        // Remove trailing slash if not root
        if ($url !== '/' && substr($url, -1) === '/') {
            $url = rtrim($url, '/');
        }

        foreach ($this->routes as $route) {
            if ($route['method'] === strtoupper($requestMethod)) {
                if (preg_match($route['route'], $url, $matches)) {
                    list($controller, $action) = explode('@', $route['controllerAction']);
                    $controller = "Admin\\Controllers\\" . $controller;
                    
                    if (class_exists($controller)) {
                        $controllerInstance = new $controller();
                        if (method_exists($controllerInstance, $action)) {
                            // Extract params from matches
                            $params = [];
                            foreach ($matches as $key => $value) {
                                if (is_string($key)) {
                                    $params[$key] = $value;
                                }
                            }
                            
                            call_user_func_array([$controllerInstance, $action], $params);
                            return;
                        } else {
                            $this->sendNotFound("Action $action not found in $controller");
                            return;
                        }
                    } else {
                        $this->sendNotFound("Controller $controller not found");
                        return;
                    }
                }
            }
        }
        
        $this->sendNotFound("Route $url not found");
    }

    private function sendNotFound($msg) {
        http_response_code(404);
        echo "404 Not Found: " . $msg;
    }
}

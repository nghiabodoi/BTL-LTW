<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VISU∀L PICK - Admin Dashboard</title>
    <!-- Modern Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-dark: #0f1115;
            --bg-card: #1a1d24;
            --text-main: #f1f1f1;
            --text-muted: #8b8d96;
            --primary: #3b82f6;
            --primary-hover: #2563eb;
            --danger: #ef4444;
            --success: #10b981;
            --border: #2a2e37;
            --sidebar-width: 250px;
        }

        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            display: flex;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--bg-card);
            border-right: 1px solid var(--border);
            height: 100vh;
            position: fixed;
            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            padding: 20px;
            font-size: 20px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            text-align: center;
            letter-spacing: 2px;
        }
        
        .sidebar-header a {
            color: #fff;
            text-decoration: none;
        }

        .sidebar-nav {
            padding: 20px 0;
            flex-grow: 1;
        }

        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-nav li a {
            display: block;
            padding: 12px 20px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s;
            font-size: 15px;
        }

        .sidebar-nav li a:hover, .sidebar-nav li a.active {
            background-color: rgba(59, 130, 246, 0.1);
            color: var(--primary);
            border-left: 3px solid var(--primary);
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid var(--border);
        }
        
        .sidebar-footer a {
            color: var(--danger);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }

        /* Main Content */
        .main-wrapper {
            margin-left: var(--sidebar-width);
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .topbar {
            height: 60px;
            background-color: var(--bg-card);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        .topbar-title {
            font-weight: 600;
            font-size: 18px;
        }

        .user-info {
            font-size: 14px;
            color: var(--text-muted);
        }

        .content {
            padding: 30px;
            flex-grow: 1;
        }

        /* Cards & Widgets */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background-color: var(--bg-card);
            border-radius: 12px;
            padding: 20px;
            border: 1px solid var(--border);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 14px;
            color: var(--text-muted);
            margin-bottom: 10px;
            font-weight: 500;
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
        }

        /* Tables */
        .table-container {
            background: var(--bg-card);
            border-radius: 12px;
            border: 1px solid var(--border);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        
        th {
            background: rgba(255,255,255,0.02);
            color: var(--text-muted);
            font-weight: 500;
            font-size: 13px;
            text-transform: uppercase;
        }
        
        td {
            font-size: 14px;
        }

        tr:last-child td {
            border-bottom: none;
        }
        
        .badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge.pending { background: rgba(245, 158, 11, 0.2); color: #f59e0b; }
        .badge.completed { background: rgba(16, 185, 129, 0.2); color: #10b981; }
        .badge.cancelled { background: rgba(239, 68, 68, 0.2); color: #ef4444; }

    </style>
</head>
<body>

    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <a href="<?= BASE_URL ?>">VISU∀L PICK</a>
        </div>
        <nav class="sidebar-nav">
            <ul>
                <li><a href="<?= BASE_URL ?>/dashboard" class="<?= strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false ? 'active' : '' ?>">Bảng điều khiển</a></li>
                <li><a href="<?= BASE_URL ?>/products" class="<?= strpos($_SERVER['REQUEST_URI'], '/products') !== false ? 'active' : '' ?>">Sản phẩm</a></li>
                <li><a href="<?= BASE_URL ?>/orders" class="<?= strpos($_SERVER['REQUEST_URI'], '/orders') !== false ? 'active' : '' ?>">Đơn hàng</a></li>
                <li><a href="<?= BASE_URL ?>/users" class="<?= strpos($_SERVER['REQUEST_URI'], '/users') !== false ? 'active' : '' ?>">Người dùng</a></li>
                <li><a href="<?= BASE_URL ?>/tickets" class="<?= strpos($_SERVER['REQUEST_URI'], '/tickets') !== false ? 'active' : '' ?>">Hỗ trợ KH</a></li>
            </ul>
        </nav>
        <div class="sidebar-footer">
            <a href="<?= BASE_URL ?>/logout">Đăng xuất</a>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="main-wrapper">
        <header class="topbar">
            <div class="topbar-title"><?php echo htmlspecialchars($pageTitle ?? 'Bảng điều khiển'); ?></div>
            <div class="user-info">
                Xin chào, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Admin'); ?>
            </div>
        </header>

        <main class="content">
            <?php echo $content; ?>
        </main>
    </div>

</body>
</html>

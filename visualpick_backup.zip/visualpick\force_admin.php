<?php
require 'db_config.php';
$stmt = $pdo->prepare("UPDATE users SET role_id = 1 WHERE email = 'admin@visualpick.com'");
$stmt->execute();
echo "Updated role_id to 1 for admin.";

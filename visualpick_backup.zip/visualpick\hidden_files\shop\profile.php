<?php
session_start();
require_once '../db_config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user info
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Get order history
$stmt_orders = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt_orders->execute([$user_id]);
$orders = $stmt_orders->fetchAll();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ của tôi - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .profile-container {
            padding: 50px 0;
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 40px;
        }
        .profile-sidebar {
            background: #111;
            padding: 30px;
            border-radius: 5px;
            border: 1px solid #222;
        }
        .profile-sidebar h3 {
            margin-bottom: 20px;
            color: #fff;
        }
        .profile-info-item {
            margin-bottom: 15px;
        }
        .profile-info-item label {
            display: block;
            color: #888;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        .profile-info-item p {
            color: #fff;
            font-size: 16px;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 20px;
            color: #ff0055;
            text-decoration: none;
            border: 1px solid #ff0055;
            padding: 10px 20px;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: #ff0055;
            color: #fff;
        }
        .orders-section {
            background: #111;
            padding: 30px;
            border-radius: 5px;
            border: 1px solid #222;
        }
        .orders-section h3 {
            margin-bottom: 20px;
            color: #fff;
        }
        .order-table {
            width: 100%;
            border-collapse: collapse;
        }
        .order-table th, .order-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #222;
        }
        .order-table th {
            color: #888;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            text-transform: uppercase;
            font-weight: bold;
        }
        .status-pending { background: #333; color: #fff; }
        .status-shipped { background: #00ff88; color: #000; }
        .status-cancelled { background: #ff0055; color: #fff; }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="index.php" class="icon-link" style="font-size: 12px; text-transform: uppercase; text-decoration: underline; margin-right: 15px;">Quay lại Trang chủ</a>
            </div>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>Hồ sơ của tôi</h1>
        </div>
    </div>

    <section class="container profile-container">
        <!-- Sidebar: Personal Info -->
        <div class="profile-sidebar">
            <h3>Thông tin tài khoản</h3>
            <div class="profile-info-item">
                <label>Họ và tên</label>
                <p><?php echo htmlspecialchars($user['fullname'] ?? ''); ?></p>
            </div>
            <div class="profile-info-item">
                <label>Email</label>
                <p><?php echo htmlspecialchars($user['email'] ?? ''); ?></p>
            </div>
            <div class="profile-info-item">
                <label>Ngày tham gia</label>
                <p><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></p>
            </div>
            
            <?php if (isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1): ?>
                <a href="admin.php" style="display: block; margin-top: 15px; color: #00ff88; text-decoration: underline;">Tới trang Quản trị (Admin)</a>
            <?php endif; ?>
            
            <a href="logout.php" class="logout-btn">Đăng xuất</a>
        </div>

        <!-- Main Content: Order History -->
        <div class="orders-section">
            <h3>Lịch sử đơn hàng</h3>
            <?php if (count($orders) > 0): ?>
                <table class="order-table">
                    <thead>
                        <tr>
                            <th>Mã Đơn</th>
                            <th>Ngày Đặt</th>
                            <th>Tổng Tiền</th>
                            <th>Trạng Thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                                <td><?php echo number_format($order['total_money'], 0, ',', '.'); ?>đ</td>
                                <td>
                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                        <?php echo $order['status']; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: #888; padding: 20px 0;">Bạn chưa có đơn hàng nào.</p>
                <a href="index.php" class="btn-primary" style="display: inline-block; margin-top: 15px;">Tiếp tục mua sắm</a>
            <?php endif; ?>
        </div>
    </section>

</body>
</html>

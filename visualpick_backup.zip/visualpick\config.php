<?php
// Cấu hình Gemini API
// Bạn có thể lấy API Key tại: https://aistudio.google.com/app/apikey
define('GEMINI_API_KEY', 'AIzaSyD6tNf1o0jTSGdDKrrqt8JN55GLPpk18QU');

// Các cấu hình khác nếu cần
?>

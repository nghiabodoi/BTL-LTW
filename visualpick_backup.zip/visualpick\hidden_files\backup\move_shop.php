<?php
$filesToMove = [
    'accessories.php', 'add_to_cart.php', 'airport-looks.php', 'artist-detail.php',
    'cart.php', 'checkout.php', 'contact.php', 'filter_products.php', 'kpop.php',
    'login.php', 'logout.php', 'lookbook.php', 'order_process.php', 'order_success.php',
    'product-detail.php', 'products.php', 'profile.php', 'register.php', 'search.php',
    'stage-outfits.php', 'submit_review.php', 'toggle_wishlist.php', 'usuk.php',
    'visual_search.php', 'vpop.php', 'wishlist.php', 'index.php'
];

$shopDir = __DIR__ . '/shop';
if (!is_dir($shopDir)) {
    mkdir($shopDir, 0777, true);
}

foreach ($filesToMove as $file) {
    if (file_exists(__DIR__ . '/' . $file)) {
        rename(__DIR__ . '/' . $file, $shopDir . '/' . $file);
    }
}

// Rewrite paths in all shop/*.php files
$shopFiles = glob($shopDir . '/*.php');
foreach ($shopFiles as $f) {
    $c = file_get_contents($f);
    
    // db_config.php
    $c = preg_replace('/([\'"])db_config\.php\1/', '$1../db_config.php$1', $c);
    
    // assets/
    $c = preg_replace('/([\'"])assets\//', '$1../assets/', $c);
    
    // api/
    $c = preg_replace('/([\'"])api\//', '$1../api/', $c);
    
    // login.php inside header, etc.
    // Actually, intra-shop links (like href="kpop.php") remain the same because they are relative!
    
    file_put_contents($f, $c);
}

// Create root index.php that redirects to shop
$rootIndex = <<<'PHP'
<?php
header("Location: shop/index.php");
exit;
PHP;
file_put_contents(__DIR__ . '/index.php', $rootIndex);

echo "Moved to shop successfully.\n";

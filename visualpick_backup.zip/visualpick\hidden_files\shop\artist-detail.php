<?php session_start(); ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
        $artist = isset($_GET['artist']) ? $_GET['artist'] : 'gdragon';
        $artist_name = "G-DRAGON";
        $artist_bio = "Biểu tượng thời trang toàn cầu và là linh hồn của phong cách Avant-garde K-Pop.";
        $cover_img = "../assets/images/G-Dragon concert photography.jpg";
        
        if($artist == 'jennie') {
            $artist_name = "JENNIE";
            $artist_bio = "Sự giao thoa hoàn hảo giữa phong cách High-fashion và phong thái 'Human Chanel'.";
            $cover_img = "../assets/images/Jennie Blackpink born pink tour outfit dark.jpg";
        } else if($artist == 'justin') {
            $artist_name = "JUSTIN BIEBER";
            $artist_bio = "Định nghĩa lại phong cách Streetwear đương đại qua những bộ trang phục Stage đặc sắc.";
            $cover_img = "../assets/images/Justin Bieber concert stage dark aesthetic.jpg";
        } else if($artist == 'sontung') {
            $artist_name = "SƠN TÙNG M-TP";
            $artist_bio = "Sức hút mãnh liệt với những lựa chọn thời trang đậm chất phá cách và thời thượng.";
            $cover_img = "../assets/images/Son Tung MTP stage performance wide.jpg";
        }
    ?>
    <title><?php echo $artist_name; ?> - ARTIST DETAIL</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .artist-hero {
            height: 90vh;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: flex-end;
            padding: 80px 0;
            background: #000;
        }
        .artist-hero-bg {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            object-fit: cover;
            opacity: 0.6;
            filter: grayscale(30%);
        }
        .artist-hero-content {
            position: relative;
            z-index: 2;
            max-width: 800px;
        }
        .artist-hero-content h1 {
            font-size: clamp(60px, 10vw, 120px);
            font-family: 'Playfair Display', serif;
            letter-spacing: 10px;
            margin-bottom: 20px;
            line-height: 1;
        }
        .artist-hero-content p {
            font-size: 18px;
            color: #ccc;
            letter-spacing: 2px;
            max-width: 600px;
        }
        .artist-story {
            padding: 120px 0;
            border-bottom: 1px solid #111;
        }
        .story-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 80px;
            align-items: center;
        }
        .story-text h2 {
            font-family: 'Playfair Display', serif;
            font-size: 40px;
            margin-bottom: 30px;
            letter-spacing: 2px;
        }
        .story-text p {
            color: #888;
            line-height: 1.8;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .artist-gallery {
            padding: 100px 0;
        }
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        .gallery-item {
            height: 600px;
            overflow: hidden;
            background: #0a0a0a;
        }
        .gallery-item img {
            width: 100%; height: 100%;
            object-fit: cover;
            transition: 0.6s;
            filter: grayscale(100%);
        }
        .gallery-item:hover img {
            filter: grayscale(0%);
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname'] ?? ''); ?></span>
                        <a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge">0</span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php" style="text-decoration: underline; color: #888;">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="artist-hero">
        <img src="<?php echo $cover_img; ?>" class="artist-hero-bg" alt="Artist Cover">
        <div class="container">
            <div class="artist-hero-content">
                <h1><?php echo $artist_name; ?></h1>
                <p><?php echo $artist_bio; ?></p>
            </div>
        </div>
    </section>

    <section class="artist-story">
        <div class="container">
            <div class="story-grid">
                <div class="story-text">
                    <h2>The Aesthetic Journey</h2>
                    <p>Mỗi lần xuất hiện là một tuyên ngôn thời trang. Không chỉ dừng lại ở trang phục, đó là cách họ thể hiện bản ngã, sự tự do và tầm ảnh hưởng sâu rộng đến văn hóa đại chúng toàn cầu.</p>
                    <p>Khám phá những khoảnh khắc biểu tượng, từ ánh đèn sân khấu rực rỡ đến những phong cách thường nhật đậm chất riêng được chúng tôi tuyển chọn kỹ lưỡng.</p>
                </div>
                <div style="height: 500px; background: #111;">
                    <img src="<?php echo $cover_img; ?>" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.8;" alt="Artistic Shot">
                </div>
            </div>
        </div>
    </section>

    <section class="artist-gallery">
        <div class="container">
            <h2 class="section-title" style="margin-bottom: 80px;">Iconic Outfits</h2>
            <div class="gallery-grid">
                <div class="gallery-item"><img src="<?php echo $cover_img; ?>" alt="G-Dragon"></div>
                <div class="gallery-item"><img src="<?php echo $cover_img; ?>" alt="G-Dragon"></div>
                <div class="gallery-item"><img src="<?php echo $cover_img; ?>" alt="G-Dragon"></div>
            </div>
        </div>
    </section>
</body>
</html>

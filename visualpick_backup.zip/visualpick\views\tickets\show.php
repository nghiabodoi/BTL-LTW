<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <h2 style="margin: 0;">Ticket #<?= $ticket['id'] ?>: <?= htmlspecialchars($ticket['subject']) ?></h2>
        <p style="margin: 5px 0 0 0; color: var(--text-muted); font-size: 14px;">
            Người gửi: <strong><?= htmlspecialchars($ticket['customer_name']) ?></strong> (<?= htmlspecialchars($ticket['email']) ?>)
        </p>
    </div>
    <a href="<?= BASE_URL ?>/tickets" class="btn btn-secondary">Quay lại</a>
</div>

<div class="grid" style="grid-template-columns: 2fr 1fr; align-items: start;">
    
    <!-- Left Column: Chat Interface -->
    <div class="card" style="display: flex; flex-direction: column; height: 600px;">
        <!-- Messages Area -->
        <div style="flex: 1; overflow-y: auto; padding-right: 10px; margin-bottom: 20px; display: flex; flex-direction: column; gap: 15px;">
            <?php if(empty($messages)): ?>
                <p style="text-align: center; color: var(--text-muted); margin-top: 20px;">Chưa có tin nhắn nào.</p>
            <?php else: ?>
                <?php foreach($messages as $msg): ?>
                    <?php if($msg['is_admin']): ?>
                        <!-- Admin Message (Right) -->
                        <div style="align-self: flex-end; max-width: 80%; background: var(--primary); color: #fff; padding: 12px 16px; border-radius: 12px 12px 0 12px;">
                            <div style="font-weight: 600; font-size: 12px; margin-bottom: 5px; opacity: 0.8; text-align: right;">Bạn (Admin)</div>
                            <div style="line-height: 1.5; font-size: 14px;"><?= nl2br(htmlspecialchars($msg['message'])) ?></div>
                            <div style="font-size: 11px; opacity: 0.6; margin-top: 5px; text-align: right;"><?= date('d/m H:i', strtotime($msg['created_at'])) ?></div>
                        </div>
                    <?php else: ?>
                        <!-- User Message (Left) -->
                        <div style="align-self: flex-start; max-width: 80%; background: #2a2e37; color: #fff; padding: 12px 16px; border-radius: 12px 12px 12px 0;">
                            <div style="font-weight: 600; font-size: 12px; margin-bottom: 5px; color: #9ca3af;"><?= htmlspecialchars($msg['sender_name']) ?></div>
                            <div style="line-height: 1.5; font-size: 14px;"><?= nl2br(htmlspecialchars($msg['message'])) ?></div>
                            <div style="font-size: 11px; color: #6b7280; margin-top: 5px;"><?= date('d/m H:i', strtotime($msg['created_at'])) ?></div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Reply Form -->
        <div style="border-top: 1px solid var(--border); padding-top: 15px;">
            <form action="<?= BASE_URL ?>/tickets/reply/<?= $ticket['id'] ?>" method="POST" style="display: flex; gap: 10px;">
                <textarea name="message" required placeholder="Nhập câu trả lời của bạn..." style="flex: 1; padding: 12px; background: #1a1d24; border: 1px solid var(--border); border-radius: 6px; color: #fff; resize: none; height: 40px; font-family: inherit;"></textarea>
                <button type="submit" class="btn btn-primary" style="padding: 0 20px;">Gửi</button>
            </form>
        </div>
    </div>

    <!-- Right Column: Status Update -->
    <div class="card">
        <h3 style="margin-top: 0; margin-bottom: 15px;">Trạng thái Ticket</h3>
        <form action="<?= BASE_URL ?>/tickets/update_status/<?= $ticket['id'] ?>" method="POST">
            <div class="form-group" style="margin-bottom: 15px;">
                <select name="status" class="form-control">
                    <?php
                        $statusMap = [
                            'open' => 'Mở',
                            'in_progress' => 'Đang xử lý',
                            'resolved' => 'Đã giải quyết',
                            'closed' => 'Đóng'
                        ];
                        foreach($statusMap as $val => $label):
                    ?>
                        <option value="<?= $val ?>" <?= $ticket['status'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-secondary" style="width: 100%;">Cập nhật Trạng thái</button>
        </form>
        
        <hr style="border: 0; border-top: 1px solid var(--border); margin: 20px 0;">
        
        <div>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 5px;"><strong>Độ ưu tiên:</strong> <span style="text-transform: uppercase;"><?= $ticket['priority'] ?></span></p>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 5px;"><strong>Ngày tạo:</strong> <?= date('d/m/Y H:i', strtotime($ticket['created_at'])) ?></p>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 0;"><strong>Cập nhật:</strong> <?= date('d/m/Y H:i', strtotime($ticket['updated_at'])) ?></p>
        </div>
    </div>
</div>

<style>
.form-control {
    width: 100%;
    padding: 10px;
    background: #242832;
    border: 1px solid var(--border);
    border-radius: 6px;
    color: #fff;
}
/* Scrollbar styling for messages area */
div::-webkit-scrollbar {
    width: 6px;
}
div::-webkit-scrollbar-track {
    background: transparent;
}
div::-webkit-scrollbar-thumb {
    background: var(--border);
    border-radius: 3px;
}
</style>

<script>
// Auto scroll to bottom of messages
document.addEventListener("DOMContentLoaded", function() {
    var msgArea = document.querySelector('div[style*="overflow-y: auto"]');
    if(msgArea) {
        msgArea.scrollTop = msgArea.scrollHeight;
    }
});
</script>

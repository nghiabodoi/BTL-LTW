<div class="card" style="max-width: 800px; margin: 0 auto;">
    <h3 style="margin-top: 0;">Sửa Sản Phẩm</h3>
    <form action="<?= BASE_URL ?>/products/update/<?= $product['id'] ?>" method="POST">
        <div class="form-group">
            <label>Tên sản phẩm</label>
            <input type="text" name="name" value="<?= htmlspecialchars($product['name'] ?? '') ?>" required class="form-control">
        </div>
        
        <div class="grid" style="grid-template-columns: 1fr 1fr; margin-bottom: 0;">
            <div class="form-group">
                <label>Giá bán (VNĐ)</label>
                <input type="text" name="price" value="<?= htmlspecialchars($product['price'] ?? '') ?>" required class="form-control">
            </div>
            <div class="form-group">
                <label>Giá khuyến mãi (Nhập 0 nếu không có)</label>
                <input type="text" name="discount" value="<?= htmlspecialchars($product['discount'] ?? '0') ?>" class="form-control">
            </div>
        </div>

        <div class="form-group">
            <label>Danh mục</label>
            <select name="category_id" required class="form-control">
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?= ($product['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Đường dẫn hình ảnh (URL)</label>
            <input type="text" name="image_url" value="<?= htmlspecialchars($product['image_url'] ?? '') ?>" class="form-control">
        </div>

        <div class="form-group">
            <label>Mô tả sản phẩm</label>
            <textarea name="description" rows="5" class="form-control"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="btn btn-primary">Lưu Thay Đổi</button>
            <a href="<?= BASE_URL ?>/products" style="margin-left: 15px; color: var(--text-muted); text-decoration: none;">Hủy</a>
        </div>
    </form>
</div>

<style>
.form-group {
    margin-bottom: 20px;
}
.form-group label {
    display: block;
    margin-bottom: 8px;
    font-size: 14px;
    color: var(--text-muted);
}
.form-control {
    width: 100%;
    padding: 12px;
    background: #242832;
    border: 1px solid var(--border);
    border-radius: 6px;
    color: #fff;
    box-sizing: border-box;
    font-family: inherit;
}
.btn {
    padding: 10px 20px;
    border-radius: 6px;
    border: none;
    font-weight: 600;
    cursor: pointer;
}
.btn-primary {
    background: var(--primary);
    color: #fff;
}
</style>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2 style="margin: 0;">Thêm Người Dùng</h2>
    <a href="<?= BASE_URL ?>/users" class="btn btn-secondary">Quay lại danh sách</a>
</div>

<div class="card" style="max-width: 600px; margin: 0 auto;">
    <form action="<?= BASE_URL ?>/users/store" method="POST">
        <div class="form-group">
            <label>Họ và Tên</label>
            <input type="text" name="fullname" required class="form-control">
        </div>
        
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" required class="form-control">
        </div>
        
        <div class="form-group">
            <label>Mật khẩu</label>
            <input type="password" name="password" required class="form-control">
        </div>

        <div class="form-group">
            <label>Nhóm Quyền</label>
            <select name="role_id" class="form-control">
                <option value="">-- Không phân quyền --</option>
                <?php foreach($roles as $role): ?>
                    <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group" style="display: flex; align-items: center; gap: 10px;">
            <input type="checkbox" name="is_active" value="1" checked id="is_active">
            <label for="is_active" style="margin: 0;">Tài khoản hoạt động</label>
        </div>

        <div class="form-group" style="margin-top: 30px;">
            <button type="submit" class="btn btn-primary">Tạo Mới</button>
        </div>
    </form>
</div>

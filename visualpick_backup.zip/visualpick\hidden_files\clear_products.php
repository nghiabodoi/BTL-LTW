<?php
require_once __DIR__ . '/../../db_config.php';

try {
    $count = $pdo->query("SELECT COUNT(*) FROM category")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("INSERT INTO category (name) VALUES ('Kpop'), ('Vpop'), ('US-UK'), ('Phụ kiện')");
        echo "Categories seeded.";
    } else {
        echo "Categories already exist.";
    }
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage();
}

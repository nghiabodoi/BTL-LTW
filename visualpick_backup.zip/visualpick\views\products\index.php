<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <button class="btn btn-primary" onclick="window.location.href='<?= BASE_URL ?>/products/create'">+ Thêm Sản Phẩm</button>
    </div>
    <div>
        <input type="text" placeholder="Tìm kiếm sản phẩm..." style="padding: 10px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-card); color: var(--text-main);">
    </div>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th style="width: 50px;"><input type="checkbox"></th>
                <th style="width: 80px;">Hình Ảnh</th>
                <th>Tên Sản Phẩm</th>
                <th>Danh Mục</th>
                <th>Giá Bán</th>
                <th>Trạng Thái</th>
                <th style="text-align: right;">Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($products as $product): ?>
            <tr>
                <td><input type="checkbox" value="<?php echo $product['id']; ?>"></td>
                <td><img src="<?php echo htmlspecialchars($product['image_url'] ?? ''); ?>" alt="img" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;"></td>
                <td style="font-weight: 500;"><?php echo htmlspecialchars($product['name'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($product['category_name'] ?? ''); ?></td>
                <td>
                    <?php echo number_format((float)($product['price'] ?? 0), 0, ',', '.'); ?> đ
                    <?php if(($product['discount'] ?? 0) > 0): ?>
                        <br><span style="font-size: 12px; color: var(--danger); text-decoration: line-through;"><?php echo number_format((float)$product['discount'], 0, ',', '.'); ?> đ</span>
                    <?php endif; ?>
                </td>
                <td><span class="badge completed">Hiển thị</span></td>
                <td style="text-align: right;">
                    <a href="<?= BASE_URL ?>/products/edit/<?php echo $product['id']; ?>" style="color: var(--primary); text-decoration: none; margin-right: 15px;">Sửa</a>
                    <form action="<?= BASE_URL ?>/products/delete/<?php echo $product['id']; ?>" method="POST" style="display: inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">
                        <button type="submit" style="background: none; border: none; color: var(--danger); cursor: pointer; font-size: 14px;">Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<style>
.btn {
    padding: 10px 20px;
    border-radius: 6px;
    border: none;
    font-weight: 600;
    cursor: pointer;
    font-size: 14px;
}
.btn-primary {
    background: var(--primary);
    color: #fff;
}
.btn-primary:hover {
    background: var(--primary-hover);
}
</style>

<?php
session_start(); // Khởi tạo session để ghi nhớ trạng thái đăng nhập
require_once '../db_config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $message = "<p style='color: #ff4d4d;'>Vui lòng nhập đầy đủ email và mật khẩu!</p>";
    } else {
        try {
            // 1. Tìm người dùng theo email
            $sql = "SELECT * FROM users WHERE email = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            // 2. Kiểm tra nếu tìm thấy người dùng
            if ($user) {
                // 3. Kiểm tra mật khẩu (hàm này sẽ tự so khớp với chuỗi đã hash)
                if (password_verify($password, $user['password'])) {
                    
                    // Đăng nhập thành công! Lưu thông tin vào Session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_fullname'] = $user['fullname'];
                    $_SESSION['role_id'] = $user['role_id'];

                    // Chuyển hướng về trang chủ
                    header("Location: index.php");
                    exit();
                } else {
                    $message = "<p style='color: #ff4d4d;'>Mật khẩu không chính xác!</p>";
                }
            } else {
                $message = "<p style='color: #ff4d4d;'>Email này không tồn tại trong hệ thống!</p>";
            }
        } catch (PDOException $e) {
            $message = "<p style='color: #ff4d4d;'>Lỗi hệ thống: " . $e->getMessage() . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="auth-section">
        <div class="auth-box">
            <h2>Đăng nhập</h2>
            <p>Chào mừng Nghĩa quay trở lại với VISU∀L PICK</p>
            
            <div class="alert-box">
                <?php echo $message; ?>
            </div>

            <form action="login.php" method="POST">
                <div class="input-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="Nhập email của bạn" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email'] ?? '') : ''; ?>">
                </div>
                
                <div class="input-group">
                    <label>Mật khẩu</label>
                    <input type="password" name="password" placeholder="Nhập mật khẩu" required>
                </div>
                
                <div class="auth-options">
                    <label><input type="checkbox"> Nhớ mật khẩu</label>
                    <a href="#">Quên mật khẩu?</a>
                </div>
                
                <button type="submit" class="btn-primary auth-btn">Đăng nhập ngay</button>
            </form>
            
            <div class="auth-switch">
                Chưa có tài khoản? <a href="register.php">Đăng ký ngay</a>
            </div>
        </div>
    </section>

</body>
</html>
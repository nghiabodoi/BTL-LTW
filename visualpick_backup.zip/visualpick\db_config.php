<?php
// Cấu hình kết nối
$host = '127.0.0.1';
$db = 'visual_pick_db';
$user = 'root';        // Mặc định của Laragon
$pass = '';            // Mặc định của Laragon
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     // Tạo kết nối bằng PDO (Bảo mật và hiện đại hơn mysqli)
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>
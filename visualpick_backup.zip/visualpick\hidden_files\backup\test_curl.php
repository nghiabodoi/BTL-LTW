<?php
$ch = curl_init('http://localhost/visualpick/admin/dashboard');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
echo "HTTP Code: " . curl_getinfo($ch, CURLINFO_HTTP_CODE) . "\n";
echo "Length: " . strlen($response) . "\n";
echo substr($response, 0, 500);

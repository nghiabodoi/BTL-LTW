<?php session_start(); ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visual Pick - Khơi nguồn cảm hứng thời trang</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left">
                <!-- Empty space to balance the icons on the right -->
            </div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." class="search-input">
                    <button type="submit" class="search-btn">
                        <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                </form>

                <a href="visual_search.php" class="icon-link" title="Tìm kiếm bằng hình ảnh">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </a>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <a href="profile.php" style="color: #fff; text-decoration: none; border-bottom: 1px solid #444; padding-bottom: 2px;">Xin chào, <?php echo htmlspecialchars($_SESSION['user_fullname']); ?></a>
                        <?php if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1): ?><a href="../" style="color: #f39c12; text-decoration: underline;">Admin Panel</a><?php endif; ?>
                        <a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="wishlist.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?></span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="hero-overlay">
            <div class="hero-content">
                <h1>THE STAGE COLLECTION</h1>
                <p style="font-family: 'Inter', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 4px; margin-top: 15px; color: #ccc;">Mặc Đẹp Như Thần Tượng Của Bạn</p>
                <a href="kpop.php" class="btn-primary" style="margin-top: 35px; padding: 15px 40px;">KHÁM PHÁ NGAY</a>
            </div>
        </div>
    </section>

    <section class="trending">
        <div class="container">
            <h2 class="section-title">Nghệ sĩ nổi bật</h2>
            
            <div class="grid-container masonry-grid spotlight-grid">
                <div class="card card-large">
                    <img src="assets/images/G-Dragon concert photography.jpg" alt="G-Dragon" style="object-position: top center;">
                    <div class="card-info overlay-info">
                        <h3>G-Dragon</h3>
                        <p>K-Pop Outfit</p>
                    </div>
                </div>

                <div class="card card-wide">
                    <img src="assets/images/Son Tung MTP stage performance wide.jpg" alt="Sơn Tùng" style="object-position: top center;">
                    <div class="card-info overlay-info">
                        <h3>Sơn Tùng M-TP</h3>
                        <p>V-Pop Outfit</p>
                    </div>
                </div>

                <div class="card">
                    <img src="assets/images/Jennie Blackpink born pink tour outfit dark.jpg" alt="Jennie" style="object-position: top center;">
                    <div class="card-info overlay-info">
                        <h3>Jennie (BLACKPINK)</h3>
                        <p>K-Pop Outfit</p>
                    </div>
                </div>

                <div class="card">
                    <img src="assets/images/Justin Bieber concert stage dark aesthetic.jpg" alt="Justin Bieber" style="object-position: top center;">
                    <div class="card-info overlay-info">
                        <h3>Justin Bieber</h3>
                        <p>US-UK Outfit</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="special-collection">
        <div class="container">
            <div class="intro-header">
                <h2>THE COLLECTIONS</h2>
                <p>Khám phá bản ngã của bạn qua những bộ sưu tập mang đậm dấu ấn nghệ thuật và âm nhạc.</p>
            </div>

            <div class="special-grid">
                <!-- Stage Outfits -->
                <div class="special-card">
                    <a href="stage-outfits.php" class="special-img-link">
                        <img src="assets/images/Kpop stage outfit.jpg" alt="Stage Outfit">
                    </a>
                    <div class="special-info">
                        <h3>STAGE OUTFITS</h3>
                        <p>Tỏa sáng như thần tượng với những bộ trang phục lộng lẫy, cắt xẻ táo bạo và chất liệu bắt sáng dành riêng cho ánh đèn sân khấu.</p>
                        <a href="stage-outfits.php" class="btn-cta">KHÁM PHÁ NGAY</a>
                    </div>
                </div>

                <!-- Airport Looks -->
                <div class="special-card">
                    <a href="airport-looks.php" class="special-img-link">
                        <img src="assets/images/Korean airport fashion aesthetic.jpg" alt="Airport Look">
                    </a>
                    <div class="special-info">
                        <h3>AIRPORT LOOKS</h3>
                        <p>Sự giao thoa hoàn hảo giữa tính ứng dụng thoải mái và vẻ đẹp thanh lịch ngầm. Phong cách "off-duty" chuẩn sao Hàn.</p>
                        <a href="airport-looks.php" class="btn-cta">KHÁM PHÁ NGAY</a>
                    </div>
                </div>

                <!-- Accessories -->
                <div class="special-card">
                    <a href="accessories.php" class="special-img-link">
                        <img src="assets/images/chunky jewelry aesthetic.jpg" alt="Accessories">
                    </a>
                    <div class="special-info">
                        <h3>EXCLUSIVE ACCESSORIES</h3>
                        <p>Những điểm nhấn tinh tế cuối cùng. Từ kính râm to bản đến trang sức đính đá, khẳng định đẳng cấp trong từng chi tiết.</p>
                        <a href="accessories.php" class="btn-cta">KHÁM PHÁ NGAY</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="unique-values">
        <div class="container">
            <div class="value-row">
                <div class="value-img">
                    <img src="assets/images/soobin hoang son.jpg" alt="Soobin Hoang Son">
                </div>
                <div class="value-text">
                    <h4 style="color: #888; letter-spacing: 4px; font-size: 11px; margin-bottom: 15px; font-family: 'Inter', sans-serif; font-weight: 500;">SPRING/SUMMER 2026</h4>
                    <h3 style="font-size: 42px; margin-bottom: 25px; line-height: 1.2;">NGHỆ THUẬT GIAO THOA</h3>
                    <p style="margin-bottom: 40px; font-size: 15px; color: #aaa;">VISU∀L PICK không chỉ là quần áo. Chúng tôi là cầu nối giữa thứ âm nhạc bạn yêu và phong cách bạn chọn. Mỗi sản phẩm là một tuyệt tác được tinh tuyển cẩn trọng, mang theo hơi thở của những biểu tượng nhạc Pop hàng đầu thế giới.</p>
                    <a href="#" class="btn-primary">TÌM HIỂU VỀ CHÚNG TÔI</a>
                </div>
            </div>
        </div>
    </section>

    <script>
        function toggleWishlist(element, productId) {
            fetch('toggle_wishlist.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'unauthorized') {
                    alert(data.message);
                    window.location.href = 'login.php';
                    return;
                }
                
                if (data.status === 'added') {
                    element.innerHTML = '♥';
                    element.style.color = '#ff0055';
                } else if (data.status === 'removed') {
                    element.innerHTML = '♡';
                    element.style.color = '#fff';
                }
            });
        }
    </script>
    <script src="assets/js/main.js"></script>
</body>
</html>


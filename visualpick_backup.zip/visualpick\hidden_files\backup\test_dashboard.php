<?php
require_once __DIR__ . '/db_config.php';

try {
    $revenueData = $pdo->query("
        SELECT DATE_FORMAT(order_date, '%b') as month_name, SUM(total_money) as revenue 
        FROM orders 
        WHERE status = 'delivered' AND order_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
        GROUP BY DATE_FORMAT(order_date, '%Y-%m'), DATE_FORMAT(order_date, '%b') 
        ORDER BY DATE_FORMAT(order_date, '%Y-%m') ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
    print_r($revenueData);
} catch (Exception $e) {
    echo "Error revenue: " . $e->getMessage() . "\n";
}

try {
    $statusData = $pdo->query("
        SELECT status, COUNT(*) as count 
        FROM orders 
        GROUP BY status
    ")->fetchAll(PDO::FETCH_ASSOC);
    print_r($statusData);
} catch (Exception $e) {
    echo "Error status: " . $e->getMessage() . "\n";
}

<?php
session_start();
require_once '../db_config.php';

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle remove item
if (isset($_GET['remove'])) {
    $id = (int)$_GET['remove'];
    unset($_SESSION['cart'][$id]);
    header("Location: cart.php");
    exit;
}

$products = [];
$subtotal = 0;
if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();
    
    foreach ($products as $key => $p) {
        $products[$key]['qty'] = $_SESSION['cart'][$p['id']];
        $products[$key]['total'] = $p['price'] * $products[$key]['qty'];
        $subtotal += $products[$key]['total'];
    }
}

$shipping = 30000;
$total = $subtotal + $shipping;
$_SESSION['cart_total'] = $total;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng của bạn - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." class="search-input">
                    <button type="submit" class="search-btn">
                        <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                </form>
                <a href="wishlist.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge"><?php echo array_sum($_SESSION['cart']); ?></span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>Giỏ hàng</h1>
            <p><a href="index.php">Trang chủ</a> / Giỏ hàng của bạn</p>
        </div>
    </div>

    <section class="cart-section">
        <div class="container cart-layout">
            
            <div class="cart-table-wrapper">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Đơn giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                            <th>Xóa</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 100px 0; color: #888;">Giỏ hàng của bạn đang trống.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($products as $p): ?>
                            <tr>
                                <td class="cart-product-info">
                                    <img src="<?php echo htmlspecialchars($p['image_url'] ?? ''); ?>" alt="">
                                    <div>
                                        <h4><?php echo htmlspecialchars($p['name'] ?? ''); ?></h4>
                                        <p>Thương hiệu: <?php echo htmlspecialchars($p['brand'] ?? ''); ?></p>
                                    </div>
                                </td>
                                <td><?php echo number_format($p['price'], 0, ',', '.'); ?>đ</td>
                                <td>
                                    <input type="number" value="<?php echo $p['qty']; ?>" min="1" class="qty-input" disabled>
                                </td>
                                <td class="item-total"><?php echo number_format($p['total'], 0, ',', '.'); ?>đ</td>
                                <td><a href="cart.php?remove=<?php echo $p['id']; ?>" class="remove-btn">✖</a></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="cart-summary">
                <h3>Tổng đơn hàng</h3>
                <div class="summary-row">
                    <span>Tạm tính:</span>
                    <span><?php echo number_format($subtotal, 0, ',', '.'); ?>đ</span>
                </div>
                <div class="summary-row">
                    <span>Phí giao hàng:</span>
                    <span><?php echo number_format($shipping, 0, ',', '.'); ?>đ</span>
                </div>
                <hr>
                <div class="summary-row total">
                    <span>Tổng cộng:</span>
                    <span><?php echo number_format($total, 0, ',', '.'); ?>đ</span>
                </div>
                <?php if (!empty($products)): ?>
                    <a href="checkout.php" class="btn-primary checkout-btn">Tiến hành thanh toán</a>
                <?php endif; ?>
            </div>

        </div>
    </section>

    <script src="../assets/js/main.js"></script>
</body>
</html>
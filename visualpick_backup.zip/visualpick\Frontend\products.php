<?php
session_start();
require_once __DIR__ . '/../db_config.php';

// Lấy danh sách danh mục
$categories = $pdo->query("SELECT * FROM category ORDER BY name ASC")->fetchAll();

// Lấy danh sách sản phẩm
$stmt = $pdo->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN category c ON p.category_id = c.id ORDER BY p.id DESC");
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tất cả sản phẩm - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <header class="header">
        <div class="container header-inner">
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
            <nav class="main-menu">
                <ul>
                    <li><a href="#">Kpop outfit</a></li>
                    <li><a href="#">US-UK outfit</a></li>
                    <li><a href="#">Vpop outfit</a></li>
                    <li><a href="#">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
            <div class="header-actions">
                <a href="cart.php" class="btn-primary">🛒 Giỏ hàng (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a>
            </div>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>Tất cả sản phẩm</h1>
            <p><a href="index.php">Trang chủ</a> / Sản phẩm</p>
        </div>
    </div>

    <section class="shop-page">
        <div class="container shop-layout">
            
            <aside class="sidebar">
                <div class="filter-group">
                    <h3>Danh mục</h3>
                    <ul>
                        <?php foreach($categories as $cat): ?>
                        <li><label><input type="checkbox" value="<?= $cat['id'] ?>"> <?= htmlspecialchars($cat['name']) ?></label></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </aside>

            <main class="main-content">
                <div class="products-grid-inner" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">
                    
                    <?php if (count($products) > 0): ?>
                        <?php foreach ($products as $product): ?>
                        <div class="product-card inner-card">
                            <div class="product-img-box">
                                <div class="heart-icon">♡</div>
                                <?php 
                                    // Determine image path (if it's absolute URL or local upload)
                                    $imgSrc = $product['image_url'];
                                    if (!filter_var($imgSrc, FILTER_VALIDATE_URL)) {
                                        $imgSrc = '../assets/uploads/' . basename($imgSrc);
                                    }
                                ?>
                                <img src="<?= htmlspecialchars($imgSrc) ?>" alt="<?= htmlspecialchars($product['name']) ?>" style="width: 100%; height: 350px; object-fit: cover;">
                            </div>
                            <div class="product-info">
                                <h3 class="product-title"><?= htmlspecialchars($product['name']) ?></h3>
                                <div class="product-price">
                                    <?php if($product['discount'] > 0): ?>
                                        <span class="old-price" style="text-decoration: line-through; color: #888; font-size: 13px; margin-right: 10px;"><?= number_format($product['price'], 0, ',', '.') ?>đ</span>
                                        <span class="new-price" style="color: #ff0055; font-weight: bold;"><?= number_format($product['price'] - $product['discount'], 0, ',', '.') ?>đ</span>
                                    <?php else: ?>
                                        <span class="new-price"><?= number_format($product['price'], 0, ',', '.') ?>đ</span>
                                    <?php endif; ?>
                                </div>
                                <button class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">Thêm vào giỏ</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Chưa có sản phẩm nào.</p>
                    <?php endif; ?>

                </div>
            </main>

        </div>
    </section>

    <script>
    function addToCart(productId) {
        // Redirect to cart action or use AJAX
        window.location.href = "add_to_cart.php?id=" + productId;
    }
    </script>
    <script src="assets/js/main.js"></script>
</body>
</html>


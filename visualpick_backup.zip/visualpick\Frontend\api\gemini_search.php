<?php
header('Content-Type: application/json');
require_once '../db_config.php';
require_once '../config.php';

// Kiểm tra API Key
if (GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
    echo json_encode(['error' => 'Vui lòng cấu hình GEMINI_API_KEY trong file config.php']);
    exit;
}

// Nhận dữ liệu ảnh từ POST
$data = json_decode(file_get_contents('php://input'), true);
$image_data = $data['image'] ?? '';

if (empty($image_data)) {
    echo json_encode(['error' => 'Không tìm thấy dữ liệu hình ảnh']);
    exit;
}

// Tách base64 data
if (preg_match('/^data:image\/(\w+);base64,/', $image_data, $type)) {
    $image_data = substr($image_data, strpos($image_data, ',') + 1);
    $mime_type = 'image/' . strtolower($type[1]);
} else {
    echo json_encode(['error' => 'Định dạng ảnh không hợp lệ']);
    exit;
}

// Chuẩn bị gọi Gemini API
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=" . GEMINI_API_KEY;

$prompt = "Identify the fashion item in this image. Provide 3-5 short Vietnamese keywords for searching this item in an e-commerce store. Return ONLY a JSON object with a key 'keywords' which is an array of strings. Do not include any markdown or code blocks.";

$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $prompt],
                [
                    "inline_data" => [
                        "mime_type" => $mime_type,
                        "data" => $image_data
                    ]
                ]
            ]
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http_code !== 200) {
    echo json_encode(['error' => 'Lỗi từ Gemini API: ' . $response]);
    exit;
}

$gemini_result = json_decode($response, true);
$output_text = $gemini_result['candidates'][0]['content']['parts'][0]['text'] ?? '';

// Làm sạch JSON từ Gemini (đôi khi nó vẫn trả về markdown)
$output_text = trim($output_text);
if (strpos($output_text, '```json') === 0) {
    $output_text = substr($output_text, 7, -3);
} elseif (strpos($output_text, '```') === 0) {
    $output_text = substr($output_text, 3, -3);
}

$keywords_data = json_decode($output_text, true);
$keywords = $keywords_data['keywords'] ?? [];

if (empty($keywords)) {
    echo json_encode(['error' => 'Không thể nhận dạng được từ khóa từ ảnh', 'raw' => $output_text]);
    exit;
}

// Tìm kiếm sản phẩm trong database dựa trên từ khóa
$searchResults = [];
$seenIds = [];

try {
    foreach ($keywords as $keyword) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE (name LIKE ? OR brand LIKE ? OR label LIKE ?) AND is_active = 1 LIMIT 4");
        $searchParam = "%$keyword%";
        $stmt->execute([$searchParam, $searchParam, $searchParam]);
        $rows = $stmt->fetchAll();
        
        foreach ($rows as $row) {
            if (!in_array($row['id'], $seenIds)) {
                $searchResults[] = $row;
                $seenIds[] = $row['id'];
            }
        }
        
        if (count($searchResults) >= 12) break;
    }

    echo json_encode([
        'success' => true,
        'keywords' => $keywords,
        'products' => $searchResults
    ]);

} catch (PDOException $e) {
    echo json_encode(['error' => 'Lỗi database: ' . $e->getMessage()]);
}
?>

<?php
namespace Admin\Core;

class Auth {
    public static function check() {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id'])) {
            $baseUrl = defined('BASE_URL') ? BASE_URL : '';
            header('Location: ' . $baseUrl . '/login');
            exit;
        }
        
        // Basic check for admin area access (e.g. role_id != normal user)
        // Let's assume normal users have no role_id or role_id > 3 (depending on setup)
        // Adjust this logic according to exact role definitions.
    }

    public static function hasPermission($module, $action = null) {
        if (!isset($_SESSION['role_id'])) return false;

        $role_id = $_SESSION['role_id'];
        if ($role_id == 1) return true; // Super Admin has all permissions

        $db = Database::getInstance()->getConnection();
        
        $permissionName = $action ? "{$action}_{$module}" : $module;
        
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role_id = ? AND p.name = ?
        ");
        $stmt->execute([$role_id, $permissionName]);
        
        return $stmt->fetchColumn() > 0;
    }

    public static function enforce($module, $action = null) {
        self::check();
        
        if (!self::hasPermission($module, $action)) {
            file_put_contents(__DIR__ . '/../session_debug.txt', print_r($_SESSION, true));
            http_response_code(403);
            die("
                <div style='font-family: sans-serif; text-align: center; margin-top: 50px;'>
                    <h2 style='color: red;'>403 Forbidden</h2>
                    <p>Bạn không có quyền truy cập vào khu vực Quản trị Admin.</p>
                    <p>Có thể bạn đang đăng nhập bằng tài khoản Khách hàng. Vui lòng đăng xuất và đăng nhập lại bằng tài khoản Admin.</p>
                    <p style='color: #888; font-size: 12px;'>Debug Role ID: " . (isset($_SESSION['role_id']) ? $_SESSION['role_id'] : 'None') . "</p>
                    <a href='/visualpick/logout' style='padding: 10px 20px; background: #000; color: #fff; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 20px;'>Đăng xuất & Đăng nhập lại Admin</a>
                </div>
            ");
        }
    }
}

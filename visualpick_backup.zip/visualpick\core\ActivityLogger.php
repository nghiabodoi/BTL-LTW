<?php
namespace Admin\Core;

class ActivityLogger {
    public static function log($action, $entityType = null, $entityId = null, $details = null) {
        $db = Database::getInstance()->getConnection();
        
        $userId = $_SESSION['user_id'] ?? null;
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        
        $detailsStr = is_array($details) ? json_encode($details) : $details;
        
        $stmt = $db->prepare("
            INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([$userId, $action, $entityType, $entityId, $detailsStr, $ipAddress]);
    }
}

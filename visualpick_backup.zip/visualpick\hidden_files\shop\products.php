<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tất cả sản phẩm - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

    <header class="header">
        <div class="container header-inner">
            <div class="logo"><a href="index.html">VISU∀L PICK</a></div>
            <nav class="main-menu">
                <ul>
                    <li><a href="#">Kpop outfit</a></li>
                    <li><a href="#">US-UK outfit</a></li>
                    <li><a href="#">Vpop outfit</a></li>
                    <li><a href="#">Artist Lookbook</a></li>
                    <li><a href="#">Liên hệ</a></li>
                </ul>
            </nav>
            <div class="header-actions">
                <a href="cart.html" class="btn-primary">🛒 Giỏ hàng (0)</a>
            </div>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>Tất cả sản phẩm</h1>
            <p><a href="index.html">Trang chủ</a> / Sản phẩm</p>
        </div>
    </div>

    <section class="shop-page">
        <div class="container shop-layout">
            
            <aside class="sidebar">
                <div class="filter-group">
                    <h3>Danh mục</h3>
                    <ul>
                        <li><label><input type="checkbox"> Áo thun (12)</label></li>
                        <li><label><input type="checkbox"> Áo khoác (8)</label></li>
                        <li><label><input type="checkbox"> Quần (15)</label></li>
                        <li><label><input type="checkbox"> Phụ kiện (20)</label></li>
                    </ul>
                </div>

                <div class="filter-group">
                    <h3>Nghệ sĩ</h3>
                    <ul>
                        <li><label><input type="checkbox"> G-Dragon</label></li>
                        <li><label><input type="checkbox"> BLACKPINK</label></li>
                        <li><label><input type="checkbox"> Sơn Tùng M-TP</label></li>
                        <li><label><input type="checkbox"> BTS</label></li>
                    </ul>
                </div>
            </aside>

            <main class="main-content">
                <div class="products-grid-inner">
                    
                    <div class="product-card inner-card">
                        <div class="product-img-box">
                            <div class="heart-icon">♡</div>
                            <img src="https://via.placeholder.com/300x400/1a1a1a/fff?text=Áo+Khoác" alt="Product">
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Áo Khoác Bomber Đen | G-Dragon</h3>
                            <div class="product-price"><span class="new-price">850.000đ</span></div>
                            <button class="btn-add-cart">Thêm vào giỏ</button>
                        </div>
                    </div>

                    <div class="product-card inner-card">
                        <div class="product-img-box">
                            <div class="heart-icon">♡</div>
                            <img src="https://via.placeholder.com/300x400/1a1a1a/fff?text=Áo+Thun" alt="Product">
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Áo Thun Baby Tee | Jennie</h3>
                            <div class="product-price"><span class="new-price">350.000đ</span></div>
                            <button class="btn-add-cart">Thêm vào giỏ</button>
                        </div>
                    </div>

                    </div>
            </main>

        </div>
    </section>

    <script src="../assets/js/main.js"></script>
</body>
</html>
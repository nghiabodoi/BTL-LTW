<?php
require 'db_config.php';
$tables = ['media_files', 'tickets', 'ticket_messages'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SHOW CREATE TABLE $table");
        print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage() . "\n";
    }
}

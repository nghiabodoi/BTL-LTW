<?php session_start(); ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liên hệ - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .contact-section {
            padding: 80px 0;
            display: flex;
            justify-content: center;
        }
        .contact-form-wrapper {
            max-width: 600px;
            width: 100%;
        }
        .contact-form-wrapper h2 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            margin-bottom: 20px;
            letter-spacing: 2px;
            text-align: center;
        }
        .contact-form-wrapper p {
            text-align: center;
            color: #888;
            margin-bottom: 50px;
            font-size: 13px;
            letter-spacing: 1px;
        }
        .form-group {
            margin-bottom: 30px;
            position: relative;
        }
        .form-group input, 
        .form-group textarea {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid #444;
            color: #fff;
            padding: 10px 0;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
        }
        .form-group input:focus, 
        .form-group textarea:focus {
            border-bottom: 1px solid #fff;
        }
        .form-group label {
            position: absolute;
            top: 10px;
            left: 0;
            color: #666;
            font-size: 14px;
            pointer-events: none;
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .form-group input:focus ~ label,
        .form-group input:valid ~ label,
        .form-group textarea:focus ~ label,
        .form-group textarea:valid ~ label {
            top: -15px;
            font-size: 10px;
            color: #ccc;
        }
        .btn-submit {
            background-color: #fff;
            color: #000;
            border: none;
            padding: 15px 40px;
            font-family: 'Inter', sans-serif;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: 0.3s;
            width: 100%;
            margin-top: 20px;
        }
        .btn-submit:hover {
            background-color: #ccc;
        }
        .contact-info {
            margin-top: 60px;
            text-align: center;
            border-top: 1px solid #222;
            padding-top: 40px;
        }
        .contact-info p {
            margin-bottom: 10px;
            color: #aaa;
        }
        .contact-info strong {
            color: #fff;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname'] ?? ''); ?></span>
                        <a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge">0</span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php" style="text-decoration: underline; color: #888;">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>LIÊN HỆ</h1>
            <p><a href="index.php">Trang chủ</a> / Liên hệ</p>
        </div>
    </div>

    <section class="contact-section">
        <div class="container">
            <div class="contact-form-wrapper">
                <h2>CLIENT SERVICES</h2>
                <p>Chúng tôi luôn sẵn sàng hỗ trợ bạn. Vui lòng để lại lời nhắn.</p>
                
                <form action="#" method="POST">
                    <div class="form-group">
                        <input type="text" id="name" name="name" required>
                        <label for="name">Họ và Tên</label>
                    </div>
                    
                    <div class="form-group">
                        <input type="email" id="email" name="email" required>
                        <label for="email">Email liên hệ</label>
                    </div>
                    
                    <div class="form-group">
                        <textarea id="message" name="message" rows="5" required></textarea>
                        <label for="message">Nội dung tin nhắn</label>
                    </div>
                    
                    <button type="submit" class="btn-submit">GỬI TIN NHẮN</button>
                </form>

                <div class="contact-info">
                    <p><strong>Hotline:</strong> +84 123 456 789</p>
                    <p><strong>Email:</strong> clientservice@visualpick.com</p>
                    <p><strong>Địa chỉ:</strong> Quận 1, TP. Hồ Chí Minh, Việt Nam</p>
                </div>
            </div>
        </div>
    </section>

</body>
</html>

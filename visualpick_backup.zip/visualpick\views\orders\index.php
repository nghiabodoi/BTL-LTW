<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>Quản lý Đơn Hàng</h2>
</div>

<div class="card">
    <table class="data-table">
        <thead>
            <tr>
                <th>Mã Đơn</th>
                <th>Khách Hàng</th>
                <th>Điện Thoại</th>
                <th>Tổng Tiền</th>
                <th>Ngày Đặt</th>
                <th>Trạng Thái</th>
                <th>Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($orders) > 0): ?>
                <?php foreach($orders as $order): ?>
                <tr>
                    <td>#<?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['fullname']) ?></td>
                    <td><?= htmlspecialchars($order['phone_number']) ?></td>
                    <td><?= number_format($order['total_money'], 0, ',', '.') ?> đ</td>
                    <td><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></td>
                    <td>
                        <?php
                            $statusColors = [
                                'pending' => '#FFC107',
                                'processing' => '#2196F3',
                                'shipped' => '#9C27B0',
                                'delivered' => '#4CAF50',
                                'cancelled' => '#F44336'
                            ];
                            $statusMap = [
                                'pending' => 'Chờ xử lý',
                                'processing' => 'Đang chuẩn bị',
                                'shipped' => 'Đang giao',
                                'delivered' => 'Đã giao',
                                'cancelled' => 'Đã hủy'
                            ];
                            $color = $statusColors[$order['status']] ?? '#888';
                        ?>
                        <span style="color: <?= $color ?>; font-weight: bold; text-transform: capitalize;">
                            <?= htmlspecialchars($statusMap[$order['status']] ?? $order['status']) ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?= BASE_URL ?>/orders/show/<?= $order['id'] ?>" class="btn btn-secondary btn-sm">Xem</a>
                        <form action="<?= BASE_URL ?>/orders/delete/<?= $order['id'] ?>" method="POST" style="display:inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa đơn hàng này?');">
                            <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align: center;">Chưa có đơn hàng nào.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php 
session_start(); 
require_once __DIR__ . '/../db_config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: my_tickets.php');
    exit;
}

$ticket_id = (int)$_GET['id'];

// Fetch ticket, ensuring it belongs to the logged in user
$stmt = $pdo->prepare("SELECT * FROM tickets WHERE id = ? AND user_id = ?");
$stmt->execute([$ticket_id, $_SESSION['user_id']]);
$ticket = $stmt->fetch();

if (!$ticket) {
    die("Ticket không tồn tại hoặc bạn không có quyền xem.");
}

// Handle reply submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        // Insert message
        $stmtMsg = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, user_id, message, is_admin, created_at) VALUES (?, ?, ?, 0, NOW())");
        $stmtMsg->execute([$ticket_id, $_SESSION['user_id'], $message]);
        
        // Update ticket's updated_at
        $pdo->prepare("UPDATE tickets SET updated_at = NOW() WHERE id = ?")->execute([$ticket_id]);
        
        // Refresh page
        header("Location: ticket_detail.php?id=" . $ticket_id);
        exit;
    }
}

// Fetch messages
$stmtMsg = $pdo->prepare("SELECT m.*, u.fullname FROM ticket_messages m JOIN users u ON m.user_id = u.id WHERE m.ticket_id = ? ORDER BY m.created_at ASC");
$stmtMsg->execute([$ticket_id]);
$messages = $stmtMsg->fetchAll();

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết Ticket #<?php echo $ticket['id']; ?> - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .ticket-detail-section {
            padding: 80px 0;
            display: flex;
            justify-content: center;
        }
        .ticket-wrapper {
            max-width: 800px;
            width: 100%;
        }
        .ticket-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #222;
        }
        .ticket-header h2 {
            font-size: 24px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .ticket-meta {
            color: #888;
            font-size: 13px;
        }
        .status-badge {
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: inline-block;
            margin-left: 10px;
            vertical-align: middle;
        }
        .status-open { background: rgba(0, 123, 255, 0.1); color: #007bff; border: 1px solid #007bff; }
        .status-in_progress { background: rgba(255, 193, 7, 0.1); color: #ffc107; border: 1px solid #ffc107; }
        .status-resolved { background: rgba(40, 167, 69, 0.1); color: #28a745; border: 1px solid #28a745; }
        .status-closed { background: rgba(108, 117, 125, 0.1); color: #6c757d; border: 1px solid #6c757d; }
        
        .chat-box {
            background: #0a0a0a;
            border: 1px solid #222;
            padding: 30px;
            margin-bottom: 30px;
            max-height: 500px;
            overflow-y: auto;
        }
        .message-item {
            margin-bottom: 25px;
            clear: both;
        }
        .message-item:last-child {
            margin-bottom: 0;
        }
        .message-meta {
            font-size: 12px;
            color: #888;
            margin-bottom: 5px;
        }
        .message-bubble {
            background: #111;
            padding: 15px 20px;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.6;
            display: inline-block;
            max-width: 80%;
        }
        
        .msg-admin { text-align: left; }
        .msg-admin .message-bubble { background: #222; color: #fff; border-bottom-left-radius: 0; }
        .msg-admin .message-meta strong { color: #f39c12; }
        
        .msg-user { text-align: right; }
        .msg-user .message-bubble { background: #fff; color: #000; border-bottom-right-radius: 0; }
        
        .reply-form textarea {
            width: 100%;
            background: transparent;
            border: 1px solid #444;
            color: #fff;
            padding: 15px;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            outline: none;
            transition: border-color 0.3s;
            margin-bottom: 15px;
            resize: vertical;
        }
        .reply-form textarea:focus {
            border-color: #fff;
        }
        .btn-submit {
            background-color: #fff;
            color: #000;
            border: none;
            padding: 15px 30px;
            font-family: 'Inter', sans-serif;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn-submit:hover {
            background-color: #ccc;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
            <div class="header-icons">
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </a>
            </div>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>CHI TIẾT TICKET</h1>
            <p><a href="my_tickets.php">Lịch sử Hỗ trợ</a> / Ticket #<?php echo $ticket['id']; ?></p>
        </div>
    </div>

    <section class="ticket-detail-section">
        <div class="container ticket-wrapper">
            
            <div class="ticket-header">
                <h2><?php echo htmlspecialchars($ticket['subject']); ?> 
                    <span class="status-badge status-<?php echo $ticket['status']; ?>">
                        <?php 
                            $statuses = ['open' => 'Đang chờ', 'in_progress' => 'Đang xử lý', 'resolved' => 'Đã giải quyết', 'closed' => 'Đã đóng'];
                            echo $statuses[$ticket['status']] ?? $ticket['status']; 
                        ?>
                    </span>
                </h2>
                <div class="ticket-meta">
                    Tạo lúc: <?php echo date('d/m/Y H:i', strtotime($ticket['created_at'])); ?> 
                    | Cập nhật: <?php echo date('d/m/Y H:i', strtotime($ticket['updated_at'])); ?>
                </div>
            </div>

            <div class="chat-box" id="chatBox">
                <?php foreach ($messages as $msg): ?>
                    <?php if ($msg['is_admin'] == 1): ?>
                        <!-- Admin Message -->
                        <div class="message-item msg-admin">
                            <div class="message-meta">
                                <strong>CSKH VISU∀L PICK</strong> - <?php echo date('d/m/Y H:i', strtotime($msg['created_at'])); ?>
                            </div>
                            <div class="message-bubble">
                                <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- User Message -->
                        <div class="message-item msg-user">
                            <div class="message-meta">
                                <strong><?php echo htmlspecialchars($msg['fullname']); ?> (Bạn)</strong> - <?php echo date('d/m/Y H:i', strtotime($msg['created_at'])); ?>
                            </div>
                            <div class="message-bubble">
                                <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <?php if (in_array($ticket['status'], ['open', 'in_progress'])): ?>
            <form action="ticket_detail.php?id=<?php echo $ticket['id']; ?>" method="POST" class="reply-form">
                <textarea name="message" rows="4" placeholder="Nhập tin nhắn của bạn..." required></textarea>
                <div style="text-align: right;">
                    <button type="submit" class="btn-submit">GỬI PHẢN HỒI</button>
                </div>
            </form>
            <?php else: ?>
                <p style="text-align: center; color: #888; font-style: italic;">Ticket này đã được đóng và không thể nhận thêm tin nhắn.</p>
            <?php endif; ?>

        </div>
    </section>

    <script>
        // Scroll to bottom of chat box
        var chatBox = document.getElementById('chatBox');
        chatBox.scrollTop = chatBox.scrollHeight;
    </script>
</body>
</html>

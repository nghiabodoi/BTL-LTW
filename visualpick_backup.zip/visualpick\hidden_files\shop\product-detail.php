<?php
session_start();
require_once '../db_config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: index.php");
    exit;
}

// Lấy danh sách đánh giá
$stmt_reviews = $pdo->prepare("
    SELECT pr.*, u.fullname 
    FROM product_reviews pr 
    JOIN users u ON pr.user_id = u.id 
    WHERE pr.product_id = ? 
    ORDER BY pr.created_at DESC
");
$stmt_reviews->execute([$id]);
$reviews = $stmt_reviews->fetchAll();

// Tính điểm trung bình
$avg_rating = 0;
if (count($reviews) > 0) {
    $sum = array_sum(array_column($reviews, 'rating'));
    $avg_rating = round($sum / count($reviews), 1);
}

// Giả định nếu chưa có ảnh thì để trống để user tự điền
$product_img = !empty($product['image_url']) ? $product['image_url'] : '';
$idol_img = !empty($product['idol_image_url']) ? $product['idol_image_url'] : '';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name'] ?? ''); ?> - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .reviews-section {
            padding: 50px 0;
            background: #0a0a0a;
            border-top: 1px solid #222;
            margin-top: 50px;
        }
        .reviews-header {
            margin-bottom: 30px;
        }
        .review-card {
            background: #111;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .review-rating {
            color: #ffaa00;
            margin-bottom: 10px;
        }
        .review-author {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .review-date {
            font-size: 12px;
            color: #888;
            margin-bottom: 10px;
        }
        .review-comment {
            font-size: 14px;
            line-height: 1.6;
        }
        .review-form {
            background: #111;
            padding: 30px;
            border-radius: 5px;
            margin-top: 40px;
        }
        .review-form h3 {
            margin-bottom: 20px;
        }
        .review-form textarea {
            width: 100%;
            background: #000;
            border: 1px solid #333;
            color: #fff;
            padding: 15px;
            border-radius: 5px;
            min-height: 100px;
            margin-bottom: 20px;
            resize: vertical;
        }
        .rating-select {
            background: #000;
            border: 1px solid #333;
            color: #fff;
            padding: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
            <div class="header-icons">
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." class="search-input">
                    <button type="submit" class="search-btn">
                        <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                </form>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname'] ?? ''); ?></span>
                        <a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="wishlist.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?></span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="product-detail-section">
        <div class="container product-detail-grid">
            
            <div class="product-gallery-container">
                <div class="gallery-side-controls">
                    <button class="view-btn active" id="btn-product-view" onclick="switchView('product')">
                        <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                        Product View
                    </button>
                    <button class="view-btn" id="btn-idol-view" onclick="switchView('idol')">
                        <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                        Idol Inspo
                    </button>
                </div>
                <div class="main-image-box">
                    <img id="main-product-img" src="<?php echo $product_img; ?>" alt="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" onerror="this.src='https://via.placeholder.com/600x800/0a0a0a/fff?text=CHÈN+ẢNH+TẠI+ĐÂY'">
                </div>
            </div>

            <div class="product-detail-info">
                <?php if (!empty($product['label'])): ?>
                    <div class="badge"><?php echo htmlspecialchars($product['label'] ?? ''); ?></div>
                <?php endif; ?>
                <p style="color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 10px;"><?php echo htmlspecialchars($product['brand'] ?? ''); ?></p>
                <h1><?php echo htmlspecialchars($product['name'] ?? ''); ?></h1>
                <p class="price"><?php echo number_format($product['price'], 0, ',', '.'); ?> VND</p>

                <div class="selection-group">
                    <span class="selection-label">Asian Size (Women)</span>
                    <div class="size-pills">
                        <div class="size-pill">S</div>
                        <div class="size-pill active">M</div>
                        <div class="size-pill">L</div>
                        <div class="size-pill">XL</div>
                    </div>
                </div>

                <button class="add-to-cart-btn" onclick="addToCart(<?php echo $product['id']; ?>)">ADD TO CART</button>

                <div class="shipping-info">
                    <p>● Giao hàng miễn phí cho đơn hàng từ 1.000.000 VND</p>
                    <p>● Thời gian vận chuyển dự kiến: 2 - 5 ngày làm việc</p>
                    <p>● Đổi trả trong vòng 7 ngày nếu có lỗi từ nhà sản xuất</p>
                </div>
            </div>

        </div>
    </section>

    <section class="reviews-section" id="reviews">
        <div class="container">
            <div class="reviews-header">
                <h2>Đánh giá sản phẩm (<?php echo count($reviews); ?>)</h2>
                <?php if (count($reviews) > 0): ?>
                    <p style="color: #ffaa00; font-size: 18px; margin-top: 10px;">
                        <?php echo str_repeat('★', round($avg_rating)) . str_repeat('☆', 5 - round($avg_rating)); ?> 
                        <span style="color: #fff; font-size: 14px;">(<?php echo $avg_rating; ?>/5)</span>
                    </p>
                <?php endif; ?>
            </div>

            <div class="reviews-list">
                <?php if (count($reviews) > 0): ?>
                    <?php foreach ($reviews as $rev): ?>
                        <div class="review-card">
                            <div class="review-rating">
                                <?php echo str_repeat('★', $rev['rating']) . str_repeat('☆', 5 - $rev['rating']); ?>
                            </div>
                            <div class="review-author"><?php echo htmlspecialchars($rev['fullname'] ?? ''); ?></div>
                            <div class="review-date"><?php echo date('d/m/Y H:i', strtotime($rev['created_at'])); ?></div>
                            <div class="review-comment"><?php echo nl2br(htmlspecialchars($rev['comment'] ?? '')); ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: #888;">Chưa có đánh giá nào cho sản phẩm này.</p>
                <?php endif; ?>
            </div>

            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="review-form">
                    <h3>Viết đánh giá của bạn</h3>
                    <form action="submit_review.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <div>
                            <label style="display: block; margin-bottom: 10px;">Xếp hạng:</label>
                            <select name="rating" class="rating-select">
                                <option value="5">5 Sao - Tuyệt vời</option>
                                <option value="4">4 Sao - Rất tốt</option>
                                <option value="3">3 Sao - Bình thường</option>
                                <option value="2">2 Sao - Tạm được</option>
                                <option value="1">1 Sao - Kém</option>
                            </select>
                        </div>
                        <textarea name="comment" placeholder="Chia sẻ cảm nhận của bạn về sản phẩm..." required></textarea>
                        <button type="submit" class="btn-primary">Gửi Đánh Giá</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="review-form" style="text-align: center;">
                    <p>Vui lòng <a href="login.php" style="color: #fff; text-decoration: underline;">đăng nhập</a> để viết đánh giá.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <script>
        const productImg = "<?php echo $product_img; ?>";
        const idolImg = "<?php echo $idol_img; ?>";
        const mainImg = document.getElementById('main-product-img');
        const btnProduct = document.getElementById('btn-product-view');
        const btnIdol = document.getElementById('btn-idol-view');

        function switchView(type) {
            if (type === 'product') {
                mainImg.src = productImg || 'https://via.placeholder.com/600x800/0a0a0a/fff?text=CHÈN+ẢNH+PRODUCT+TẠI+ĐÂY';
                btnProduct.classList.add('active');
                btnIdol.classList.remove('active');
            } else {
                mainImg.src = idolImg || 'https://via.placeholder.com/600x800/0a0a0a/fff?text=CHÈN+ẢNH+IDOL+TẠI+ĐÂY';
                btnIdol.classList.add('active');
                btnProduct.classList.remove('active');
            }
        }
        function addToCart(productId) {
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId + '&quantity=1'
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    document.querySelector('.cart-badge').innerHTML = data.total_items;
                    alert('Đã thêm vào giỏ hàng!');
                }
            });
        }
    </script>
</body>
</html>

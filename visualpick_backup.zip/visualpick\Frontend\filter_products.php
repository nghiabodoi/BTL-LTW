<?php
require_once __DIR__ . '/../db_config.php';

$category_id = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 1;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'default';
$price_range = isset($_GET['price']) ? $_GET['price'] : 'all';

// Xây dựng câu lệnh SQL cơ bản
$sql = "SELECT * FROM products WHERE category_id = :cat AND is_active = 1";
$params = [':cat' => $category_id];

// Lọc theo giá
if ($price_range === 'under-2m') {
    $sql .= " AND price < 2000000";
} elseif ($price_range === '2m-5m') {
    $sql .= " AND price BETWEEN 2000000 AND 5000000";
} elseif ($price_range === 'over-5m') {
    $sql .= " AND price > 5000000";
}

// Sắp xếp
if ($sort === 'newest') {
    $sql .= " ORDER BY id DESC";
} elseif ($sort === 'price-low') {
    $sql .= " ORDER BY price ASC";
} elseif ($sort === 'price-high') {
    $sql .= " ORDER BY price DESC";
}

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();

    if (count($products) > 0) {
        foreach ($products as $item) {
            ?>
            <a href="product-detail.php?id=<?php echo $item['id']; ?>" class="product-card" style="display: block; text-decoration: none; color: inherit;">
                <div class="product-img-box">
                    <div class="heart-icon">♡</div>
                    <?php if (!empty($item['label'])): ?>
                        <div class="badge"><?php echo htmlspecialchars($item['label'] ?? ''); ?></div>
                    <?php endif; ?>
                    <img src="<?php echo filter_var($item['image_url'], FILTER_VALIDATE_URL) ? htmlspecialchars($item['image_url']) : '../assets/uploads/' . basename($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" onerror="this.src='https://via.placeholder.com/300x400/0a0a0a/fff?text=CHÈN+ẢNH'">
                </div>
                <div class="product-info">
                    <p class="brand"><?php echo htmlspecialchars($item['brand'] ?? ''); ?></p>
                    <h3 class="product-title"><?php echo htmlspecialchars($item['name']); ?></h3>
                    <p class="product-price"><?php echo number_format($item['price'], 0, ',', '.'); ?> VND</p>
                </div>
            </a>
            <?php
        }
    } else {
        echo '<p style="text-align: center; grid-column: 1/-1; color: #888; padding: 40px 0;">Không tìm thấy sản phẩm phù hợp với bộ lọc.</p>';
    }
} catch (PDOException $e) {
    echo "Lỗi: " . $e->getMessage();
}
?>


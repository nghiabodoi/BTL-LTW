<?php
require_once __DIR__ . '/db_config.php';
$stmt = $pdo->query("SHOW CREATE TABLE order_details");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

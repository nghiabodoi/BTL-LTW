<?php 
session_start(); 
require_once __DIR__ . '/../db_config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM tickets WHERE user_id = ? ORDER BY updated_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$tickets = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch sử Hỗ trợ - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .tickets-section {
            padding: 80px 0;
            min-height: 50vh;
        }
        .tickets-table {
            width: 100%;
            border-collapse: collapse;
            background: #0a0a0a;
        }
        .tickets-table th, .tickets-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #222;
        }
        .tickets-table th {
            color: #888;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .tickets-table td {
            font-size: 14px;
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .status-open { background: rgba(0, 123, 255, 0.1); color: #007bff; border: 1px solid #007bff; }
        .status-in_progress { background: rgba(255, 193, 7, 0.1); color: #ffc107; border: 1px solid #ffc107; }
        .status-resolved { background: rgba(40, 167, 69, 0.1); color: #28a745; border: 1px solid #28a745; }
        .status-closed { background: rgba(108, 117, 125, 0.1); color: #6c757d; border: 1px solid #6c757d; }
        
        .btn-view {
            color: #fff;
            text-decoration: underline;
            font-size: 12px;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname']); ?></span>
                        <a href="my_tickets.php" style="color: #fff; text-decoration: underline;">Hỗ trợ</a>
                        <?php if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1): ?><a href="../" style="color: #f39c12; text-decoration: underline; margin-right: 10px;">Admin Panel</a><?php endif; ?><a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge"><?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : '0'; ?></span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php" style="color: #888;">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>LỊCH SỬ HỖ TRỢ</h1>
            <p><a href="index.php">Trang chủ</a> / Lịch sử Hỗ trợ</p>
        </div>
    </div>

    <section class="tickets-section">
        <div class="container">
            <?php if (empty($tickets)): ?>
                <p style="text-align: center; color: #888; margin-top: 50px;">Bạn chưa gửi yêu cầu hỗ trợ nào.</p>
                <div style="text-align: center; margin-top: 20px;">
                    <a href="contact.php" style="color: #fff; text-decoration: underline;">Gửi yêu cầu mới</a>
                </div>
            <?php else: ?>
                <div style="margin-bottom: 20px; text-align: right;">
                    <a href="contact.php" style="color: #fff; text-decoration: underline; font-size: 13px;">+ Tạo yêu cầu mới</a>
                </div>
                <div style="overflow-x: auto;">
                    <table class="tickets-table">
                        <thead>
                            <tr>
                                <th>Mã Ticket</th>
                                <th>Chủ đề</th>
                                <th>Trạng thái</th>
                                <th>Ngày tạo</th>
                                <th>Cập nhật lần cuối</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $t): ?>
                            <tr>
                                <td>#<?php echo $t['id']; ?></td>
                                <td><?php echo htmlspecialchars($t['subject']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $t['status']; ?>">
                                        <?php 
                                            $statuses = [
                                                'open' => 'Đang chờ',
                                                'in_progress' => 'Đang xử lý',
                                                'resolved' => 'Đã giải quyết',
                                                'closed' => 'Đã đóng'
                                            ];
                                            echo $statuses[$t['status']] ?? $t['status']; 
                                        ?>
                                    </span>
                                </td>
                                <td style="color: #888; font-size: 12px;"><?php echo date('d/m/Y H:i', strtotime($t['created_at'])); ?></td>
                                <td style="color: #888; font-size: 12px;"><?php echo date('d/m/Y H:i', strtotime($t['updated_at'])); ?></td>
                                <td>
                                    <a href="ticket_detail.php?id=<?php echo $t['id']; ?>" class="btn-view">Xem chi tiết</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>

</body>
</html>

<?php
require_once __DIR__ . '/db_config.php';
$tables = ['users', 'orders', 'order_items'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SHOW CREATE TABLE $table");
        print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
    } catch (PDOException $e) {
        echo "Table $table does not exist or error: " . $e->getMessage() . "\n";
    }
}

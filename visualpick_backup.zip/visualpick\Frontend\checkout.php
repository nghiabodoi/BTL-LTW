<?php
session_start();
require_once __DIR__ . '/../db_config.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

$cart_items = [];
$subtotal = 0;

if (!empty($_SESSION['cart'])) {
    $ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();
    
    foreach ($products as $product) {
        $qty = $_SESSION['cart'][$product['id']];
        $total = $product['price'] * $qty;
        $subtotal += $total;
        $cart_items[] = [
            'name' => $product['name'],
            'price' => $product['price'],
            'qty' => $qty,
            'total' => $total,
            'image' => $product['image_url']
        ];
    }
}

$shipping = 30000;
$total = $subtotal + $shipping;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .checkout-container {
            display: grid;
            grid-template-columns: 1.5fr 1fr;
            gap: 60px;
            padding: 80px 0;
        }
        .checkout-form h2 {
            font-size: 24px;
            margin-bottom: 30px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .form-section {
            margin-bottom: 40px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-size: 11px;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }
        .form-control {
            width: 100%;
            background: #0a0a0a;
            border: 1px solid #222;
            padding: 15px;
            color: #fff;
            outline: none;
            transition: 0.3s;
        }
        .form-control:focus {
            border-color: #fff;
        }
        .order-review {
            background: #0a0a0a;
            padding: 40px;
            border: 1px solid #222;
            position: sticky;
            top: 120px;
        }
        .review-item {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #111;
        }
        .review-item img {
            width: 60px;
            height: 80px;
            object-fit: cover;
        }
        .review-info h4 {
            font-size: 13px;
            margin-bottom: 5px;
        }
        .review-info p {
            font-size: 12px;
            color: #888;
        }
        .place-order-btn {
            width: 100%;
            padding: 20px;
            background: #fff;
            color: #000;
            border: none;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 30px;
            transition: 0.3s;
        }
        .place-order-btn:hover {
            background: #e5e5e5;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
            <div class="header-icons">
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </a>
            </div>
        </div>
    </header>

    <div class="container checkout-container">
        <div class="checkout-form">
            <form action="order_process.php" method="POST">
                <div class="form-section">
                    <h2>Thông tin giao hàng</h2>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Họ tên</label>
                            <input type="text" name="fullname" class="form-control" required value="<?php echo isset($_SESSION['user_fullname']) ? htmlspecialchars($_SESSION['user_fullname']) : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label>Số điện thoại</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Địa chỉ nhận hàng</label>
                        <input type="text" name="address" class="form-control" placeholder="Số nhà, tên đường..." required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Tỉnh / Thành phố</label>
                            <input type="text" name="city" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Quận / Huyện</label>
                            <input type="text" name="district" class="form-control" required>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h2>Phương thức thanh toán</h2>
                    <div class="form-group" style="display: flex; align-items: center; gap: 10px; background: #0a0a0a; padding: 20px; border: 1px solid #222;">
                        <input type="radio" name="payment_method" value="cod" checked style="accent-color: #fff;">
                        <label style="margin-bottom: 0; color: #fff;">Thanh toán khi nhận hàng (COD)</label>
                    </div>
                </div>

                <button type="submit" class="place-order-btn">ĐẶT HÀNG NGAY</button>
            </form>
        </div>

        <div class="order-review">
            <h2>Tóm tắt đơn hàng</h2>
            <div style="margin-top: 30px;">
                <?php foreach ($cart_items as $item): ?>
                <div class="review-item">
                    <img src="<?php echo filter_var($item['image'], FILTER_VALIDATE_URL) ? htmlspecialchars($item['image']) : '../assets/uploads/' . basename($item['image']); ?>" alt="">
                    <div class="review-info">
                        <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                        <p>Số lượng: <?php echo $item['qty']; ?></p>
                        <p><?php echo number_format($item['price'], 0, ',', '.'); ?> VND</p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top: 30px;">
                <div class="summary-row">
                    <span>Tạm tính:</span>
                    <span><?php echo number_format($subtotal, 0, ',', '.'); ?> VND</span>
                </div>
                <div class="summary-row">
                    <span>Phí giao hàng:</span>
                    <span><?php echo number_format($shipping, 0, ',', '.'); ?> VND</span>
                </div>
                <hr style="border: none; border-top: 1px solid #222; margin: 20px 0;">
                <div class="summary-row total" style="font-size: 20px;">
                    <span>TỔNG CỘNG:</span>
                    <span><?php echo number_format($total, 0, ',', '.'); ?> VND</span>
                </div>
            </div>
        </div>
    </div>

</body>
</html>


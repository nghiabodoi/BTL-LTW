<?php
session_start();
require_once '../db_config.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm kiếm bằng hình ảnh - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .visual-search-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background: #111;
            border: 1px solid #333;
            border-radius: 8px;
            text-align: center;
        }
        .camera-box {
            width: 100%;
            max-width: 500px;
            margin: 20px auto;
            background: #000;
            border-radius: 8px;
            overflow: hidden;
            position: relative;
            aspect-ratio: 4/3;
        }
        #video, #canvas {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        #preview-img {
            display: none;
            width: 100%;
            max-width: 300px;
            margin: 20px auto;
            border-radius: 8px;
            border: 2px solid #ff0055;
        }
        .controls {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .spinner {
            width: 50px;
            height: 50px;
            border: 3px solid #333;
            border-top: 3px solid #ff0055;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        .results-section {
            margin-top: 50px;
        }
        .keyword-badge {
            display: inline-block;
            padding: 5px 15px;
            background: #333;
            border-radius: 20px;
            font-size: 12px;
            margin: 5px;
            color: #ccc;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
            <div class="header-icons">
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>TÌM KIẾM BẰNG HÌNH ẢNH</h1>
            <p><a href="index.php">Trang chủ</a> / Visual Search</p>
        </div>
    </div>

    <div class="container">
        <div class="visual-search-container">
            <h2 style="margin-bottom: 20px;">Chụp ảnh hoặc tải ảnh lên để tìm sản phẩm</h2>
            
            <div class="camera-box" id="camera-box">
                <video id="video" autoplay playsinline></video>
                <canvas id="canvas" style="display:none;"></canvas>
            </div>
            
            <img id="preview-img" alt="Preview">

            <div class="controls">
                <button id="btn-capture" class="btn-primary">CHỤP ẢNH</button>
                <label for="upload-input" class="btn-secondary" style="cursor: pointer; padding: 12px 25px; border: 1px solid #444; font-size: 11px; letter-spacing: 2px;">
                    TẢI ẢNH LÊN
                </label>
                <input type="file" id="upload-input" accept="image/*" style="display:none;">
                <button id="btn-retake" class="btn-secondary" style="display:none; padding: 12px 25px; border: 1px solid #444; font-size: 11px; letter-spacing: 2px;">CHỤP LẠI</button>
            </div>
            
            <button id="btn-search" class="btn-primary" style="margin-top: 30px; display: none; width: 100%;">TÌM KIẾM SẢN PHẨM</button>
        </div>

        <div id="results-area" class="results-section" style="display: none;">
            <h2 class="section-title" id="results-title">KẾT QUẢ GỢI Ý</h2>
            <div id="keyword-container" style="text-align: center; margin-bottom: 30px;"></div>
            <div class="products-grid-inner" id="products-grid">
                <!-- Results will be injected here -->
            </div>
        </div>
    </div>

    <div class="loading-overlay" id="loading-overlay">
        <div class="spinner"></div>
        <p style="color: #fff; letter-spacing: 2px; font-size: 12px;">GEMINI ĐANG PHÂN TÍCH HÌNH ẢNH...</p>
    </div>

    <script>
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const previewImg = document.getElementById('preview-img');
        const btnCapture = document.getElementById('btn-capture');
        const btnRetake = document.getElementById('btn-retake');
        const btnSearch = document.getElementById('btn-search');
        const uploadInput = document.getElementById('upload-input');
        const cameraBox = document.getElementById('camera-box');
        const loadingOverlay = document.getElementById('loading-overlay');
        const resultsArea = document.getElementById('results-area');
        const productsGrid = document.getElementById('products-grid');
        const keywordContainer = document.getElementById('keyword-container');

        let stream;

        // Bật camera
        async function initCamera() {
            try {
                stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                video.srcObject = stream;
            } catch (err) {
                console.error("Không thể mở camera: ", err);
                cameraBox.innerHTML = '<p style="padding: 20px; color: #888;">Camera không khả dụng. Vui lòng tải ảnh lên.</p>';
                btnCapture.style.display = 'none';
            }
        }

        initCamera();

        // Chụp ảnh
        btnCapture.addEventListener('click', () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            const dataUrl = canvas.toDataURL('image/jpeg');
            
            showPreview(dataUrl);
        });

        // Tải ảnh lên
        uploadInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    showPreview(event.target.result);
                };
                reader.readAsDataURL(file);
            }
        });

        function showPreview(dataUrl) {
            previewImg.src = dataUrl;
            previewImg.style.display = 'block';
            cameraBox.style.display = 'none';
            btnCapture.style.display = 'none';
            btnRetake.style.display = 'inline-block';
            btnSearch.style.display = 'block';
        }

        btnRetake.addEventListener('click', () => {
            previewImg.style.display = 'none';
            cameraBox.style.display = 'block';
            btnCapture.style.display = 'inline-block';
            btnRetake.style.display = 'none';
            btnSearch.style.display = 'none';
            resultsArea.style.display = 'none';
        });

        btnSearch.addEventListener('click', async () => {
            const imageData = previewImg.src;
            loadingOverlay.style.display = 'flex';
            
            try {
                const response = await fetch('../api/gemini_search.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ image: imageData })
                });
                
                const data = await response.json();
                
                if (data.error) {
                    alert(data.error);
                } else {
                    displayResults(data);
                }
            } catch (err) {
                alert("Đã xảy ra lỗi khi kết nối với server.");
                console.error(err);
            } finally {
                loadingOverlay.style.display = 'none';
            }
        });

        function displayResults(data) {
            resultsArea.style.display = 'block';
            productsGrid.innerHTML = '';
            keywordContainer.innerHTML = '';

            // Hiển thị từ khóa
            data.keywords.forEach(kw => {
                const span = document.createElement('span');
                span.className = 'keyword-badge';
                span.textContent = kw;
                keywordContainer.appendChild(span);
            });

            if (data.products.length === 0) {
                productsGrid.innerHTML = '<p style="text-align: center; grid-column: 1/-1; color: #888; padding: 40px;">Không tìm thấy sản phẩm nào tương ứng. Hãy thử lại với ảnh khác.</p>';
            } else {
                data.products.forEach(item => {
                    const card = `
                        <a href="product-detail.php?id=${item.id}" class="product-card">
                            <div class="product-img-box">
                                <div class="heart-icon">♡</div>
                                ${item.label ? `<div class="badge">${item.label}</div>` : ''}
                                <img src="${item.image_url}" alt="${item.name}" onerror="this.src='https://via.placeholder.com/300x400/0a0a0a/fff?text=NO+IMAGE'">
                            </div>
                            <div class="product-info">
                                <p class="brand">${item.brand}</p>
                                <h3 class="product-title">${item.name}</h3>
                                <p class="product-price">${new Intl.NumberFormat('vi-VN').format(item.price)} VND</p>
                            </div>
                        </a>
                    `;
                    productsGrid.insertAdjacentHTML('beforeend', card);
                });
            }
            
            // Cuộn xuống kết quả
            resultsArea.scrollIntoView({ behavior: 'smooth' });
        }
    </script>
    <script src="../assets/js/main.js"></script>
</body>
</html>

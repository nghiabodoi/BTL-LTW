<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>Danh sách Hỗ trợ (Tickets)</h2>
</div>

<div class="card">
    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Khách Hàng</th>
                <th>Tiêu Đề</th>
                <th>Độ Ưu Tiên</th>
                <th>Trạng Thái</th>
                <th>Cập Nhật Lần Cuối</th>
                <th>Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($tickets) > 0): ?>
                <?php foreach($tickets as $ticket): ?>
                <tr>
                    <td>#<?= $ticket['id'] ?></td>
                    <td><?= htmlspecialchars($ticket['customer_name']) ?></td>
                    <td style="font-weight: 500;"><?= htmlspecialchars($ticket['subject']) ?></td>
                    <td>
                        <?php
                            $priorityColors = [
                                'low' => '#4CAF50',
                                'medium' => '#FFC107',
                                'high' => '#FF9800',
                                'urgent' => '#F44336'
                            ];
                            $pColor = $priorityColors[$ticket['priority']] ?? '#888';
                        ?>
                        <span style="color: <?= $pColor ?>; font-weight: bold; text-transform: uppercase; font-size: 12px;">
                            <?= htmlspecialchars($ticket['priority']) ?>
                        </span>
                    </td>
                    <td>
                        <?php
                            $statusColors = [
                                'open' => 'pending',
                                'in_progress' => 'primary',
                                'resolved' => 'completed',
                                'closed' => 'cancelled'
                            ];
                            $statusMap = [
                                'open' => 'Mở',
                                'in_progress' => 'Đang xử lý',
                                'resolved' => 'Đã giải quyết',
                                'closed' => 'Đóng'
                            ];
                            $class = $statusColors[$ticket['status']] ?? '';
                        ?>
                        <span class="badge <?= $class ?>">
                            <?= $statusMap[$ticket['status']] ?? htmlspecialchars($ticket['status']) ?>
                        </span>
                    </td>
                    <td><?= date('d/m/Y H:i', strtotime($ticket['updated_at'])) ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>/tickets/show/<?= $ticket['id'] ?>" class="btn btn-secondary btn-sm">Xem / Trả lời</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align: center; color: var(--text-muted);">Chưa có yêu cầu hỗ trợ nào.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
require_once __DIR__ . '/../../db_config.php';

$email = 'admin@visualpick.com';
$password = password_hash('admin123', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
$stmt->execute([$email]);
$exists = $stmt->fetchColumn();

if (!$exists) {
    $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, role_id, is_active) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['Super Admin', $email, $password, 1, 1]);
    echo "Created default admin account.\n";
} else {
    $stmt = $pdo->prepare("UPDATE users SET password = ?, role_id = 1 WHERE email = ?");
    $stmt->execute([$password, $email]);
    echo "Reset password for default admin account.\n";
}

echo "Email: admin@visualpick.com\n";
echo "Password: admin123\n";

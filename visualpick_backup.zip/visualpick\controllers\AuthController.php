<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Database;

class AuthController extends Controller {
    public function loginForm() {
        if (isset($_SESSION['user_id']) && isset($_SESSION['role_id'])) {
            if ($_SESSION['role_id'] == 1) {
                $this->redirect('/dashboard');
            } else {
                unset($_SESSION['user_id']);
                unset($_SESSION['role_id']);
                unset($_SESSION['user_name']);
            }
        }
        $this->view('auth.login', [], false);
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            // In visualpick, is password hashed or plain? 
            // The existing login.php uses MD5 or password_verify? 
            // I'll use a generic password_verify but fallback to plain if needed for legacy.
            // Let's assume standard password_verify.
            
            if ($user && (password_verify($password, $user['password']) || $user['password'] === $password || md5($password) === $user['password'])) {
                // Ensure user has an admin role
                if ($user['role_id'] >= 1) { // Assuming 1, 2, 3 are admin roles
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['role_id'] = $user['role_id'];
                    $_SESSION['user_name'] = $user['fullname'] ?? 'Admin';
                    
                    \Admin\Core\ActivityLogger::log('login', 'User', $user['id'], 'Admin login successful');
                    
                    $this->redirect('/dashboard');
                } else {
                    $error = "Bạn không có quyền truy cập trang quản trị.";
                    $this->view('auth.login', ['error' => $error], false);
                }
            } else {
                $error = "Email hoặc mật khẩu không đúng.";
                $this->view('auth.login', ['error' => $error], false);
            }
        }
    }

    public function logout() {
        \Admin\Core\ActivityLogger::log('logout', 'User', $_SESSION['user_id'] ?? null, 'Admin logout');
        unset($_SESSION['user_id']);
        unset($_SESSION['role_id']);
        unset($_SESSION['user_name']);
        
        $this->redirect('/login');
    }
}

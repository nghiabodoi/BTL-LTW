<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    
    if ($quantity > 0) {
        $_SESSION['cart'][$product_id] = $quantity;
        
        // Recalculate total items
        $total_items = array_sum($_SESSION['cart']);
        
        echo json_encode(['status' => 'success', 'total_items' => $total_items]);
    } else {
        // If qty is 0 or less, remove item
        unset($_SESSION['cart'][$product_id]);
        $total_items = empty($_SESSION['cart']) ? 0 : array_sum($_SESSION['cart']);
        echo json_encode(['status' => 'success', 'total_items' => $total_items]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>

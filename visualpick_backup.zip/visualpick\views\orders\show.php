<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2 style="margin: 0;">Chi Tiết Đơn Hàng #<?= $order['id'] ?></h2>
    <a href="<?= BASE_URL ?>/orders" class="btn btn-secondary">Quay lại danh sách</a>
</div>

<div class="grid" style="grid-template-columns: 2fr 1fr;">
    <!-- Left Column: Order Items -->
    <div class="card">
        <h3 style="margin-top: 0;">Sản phẩm đã mua</h3>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th>Đơn giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($items) > 0): ?>
                    <?php foreach($items as $item): ?>
                    <tr>
                        <td style="display: flex; align-items: center; gap: 10px;">
                            <img src="<?= htmlspecialchars($item['image_url'] ?? 'https://via.placeholder.com/50') ?>" alt="Product" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">
                            <span><?= htmlspecialchars($item['product_name'] ?? 'Sản phẩm không rõ') ?></span>
                        </td>
                        <td><?= number_format($item['price'], 0, ',', '.') ?> đ</td>
                        <td>x <?= $item['quantity'] ?></td>
                        <td style="font-weight: bold;"><?= number_format($item['price'] * $item['quantity'], 0, ',', '.') ?> đ</td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">Không có sản phẩm nào.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div style="margin-top: 20px; text-align: right;">
            <h3>Tổng cộng: <?= number_format($order['total_money'], 0, ',', '.') ?> đ</h3>
        </div>
    </div>

    <!-- Right Column: Customer Info & Status Update -->
    <div>
        <div class="card" style="margin-bottom: 20px;">
            <h3 style="margin-top: 0;">Thông tin Khách Hàng</h3>
            <p><strong>Họ và Tên:</strong> <?= htmlspecialchars($order['fullname']) ?></p>
            <p><strong>Điện thoại:</strong> <?= htmlspecialchars($order['phone_number']) ?></p>
            <p><strong>Địa chỉ:</strong> <?= htmlspecialchars($order['address']) ?></p>
            <p><strong>Ngày đặt:</strong> <?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></p>
            <p><strong>Phương thức TT:</strong> <span style="text-transform: uppercase;"><?= htmlspecialchars($order['payment_method']) ?></span></p>
            <?php if(!empty($order['note'])): ?>
                <p><strong>Ghi chú:</strong> <?= htmlspecialchars($order['note']) ?></p>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3 style="margin-top: 0;">Cập nhật Trạng thái</h3>
            <form action="<?= BASE_URL ?>/orders/update_status/<?= $order['id'] ?>" method="POST">
                <div class="form-group">
                    <label>Trạng thái hiện tại</label>
                    <select name="status" class="form-control" style="text-transform: capitalize;">
                        <?php
                            $statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
                            $statusMap = [
                                'pending' => 'Chờ xử lý',
                                'processing' => 'Đang chuẩn bị',
                                'shipped' => 'Đang giao',
                                'delivered' => 'Đã giao',
                                'cancelled' => 'Đã hủy'
                            ];
                            foreach($statuses as $st):
                        ?>
                            <option value="<?= $st ?>" <?= $order['status'] === $st ? 'selected' : '' ?>><?= $statusMap[$st] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Cập nhật Trạng thái</button>
            </form>
        </div>
    </div>
</div>

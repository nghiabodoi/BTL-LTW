<?php session_start(); ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artist Lookbook - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .lookbook-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            grid-auto-rows: 450px;
            gap: 20px;
            margin-bottom: 80px;
        }
        .lookbook-item {
            position: relative;
            overflow: hidden;
            border: 1px solid #222;
        }
        .lookbook-item.large-item {
            grid-column: span 2;
            grid-row: span 2;
        }
        .lookbook-item.wide-item {
            grid-column: span 2;
        }
        .lookbook-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease, filter 0.6s ease;
            filter: grayscale(20%);
        }
        .lookbook-item:hover img {
            transform: scale(1.05);
            filter: grayscale(0);
        }
        .lookbook-info {
            position: absolute;
            bottom: 0; left: 0; width: 100%;
            padding: 40px 30px 30px;
            background: linear-gradient(to top, rgba(0,0,0,0.9), transparent);
            color: #fff;
        }
        .lookbook-info h3 {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            letter-spacing: 2px;
            margin-bottom: 5px;
        }
        .lookbook-info p {
            font-size: 13px;
            color: #aaa;
            font-family: 'Inter', sans-serif;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname']); ?></span>
                        <?php if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1): ?><a href="../" style="color: #f39c12; text-decoration: underline; margin-right: 10px;">Admin Panel</a><?php endif; ?><a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge">0</span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php" style="text-decoration: underline; color: #888;">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>ARTIST LOOKBOOK</h1>
            <p><a href="index.php">Trang chủ</a> / Lookbook</p>
        </div>
    </div>

    <section class="lookbook-gallery">
        <div class="container">
            <div class="lookbook-grid">
                
                <a href="artist-detail.php?artist=gdragon" class="lookbook-item large-item">
                    <img src="assets/images/G-Dragon concert photography.jpg" alt="G-Dragon" style="object-position: top center;">
                    <div class="lookbook-info">
                        <h3>G-DRAGON</h3>
                        <p>K-Pop Fashion Icon</p>
                    </div>
                </a>

                <a href="artist-detail.php?artist=jennie" class="lookbook-item">
                    <img src="assets/images/Jennie Blackpink born pink tour outfit dark.jpg" alt="Jennie" style="object-position: top center;">
                    <div class="lookbook-info">
                        <h3>JENNIE</h3>
                        <p>Born Pink World Tour</p>
                    </div>
                </a>

                <a href="artist-detail.php?artist=justin" class="lookbook-item">
                    <img src="assets/images/Justin Bieber concert stage dark aesthetic.jpg" alt="Justin Bieber" style="object-position: top center;">
                    <div class="lookbook-info">
                        <h3>JUSTIN BIEBER</h3>
                        <p>Justice World Tour</p>
                    </div>
                </a>

                <a href="artist-detail.php?artist=sontung" class="lookbook-item wide-item">
                    <img src="assets/images/Son Tung MTP stage performance wide.jpg" alt="Son Tung MTP" style="object-position: top center;">
                    <div class="lookbook-info">
                        <h3>SƠN TÙNG M-TP</h3>
                        <p>V-Pop King</p>
                    </div>
                </a>
                
                <div class="lookbook-item">
                    <img src="https://via.placeholder.com/600x800/111/fff?text=Rose" alt="Rose">
                    <div class="lookbook-info">
                        <h3>ROSÉ</h3>
                        <p>Saint Laurent Muse</p>
                    </div>
                </div>
                
                <div class="lookbook-item">
                    <img src="https://via.placeholder.com/600x800/111/fff?text=The+Weeknd" alt="The Weeknd">
                    <div class="lookbook-info">
                        <h3>THE WEEKND</h3>
                        <p>After Hours Era</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

</body>
</html>


<?php
require_once __DIR__ . '/../../db_config.php';

$stmt = $pdo->query("SHOW CREATE TABLE roles");
print_r($stmt->fetch());

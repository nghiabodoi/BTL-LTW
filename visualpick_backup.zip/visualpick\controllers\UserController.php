<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Auth;

class UserController extends Controller {
    public function index() {
        Auth::enforce('user', 'view');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        // Fetch users and their roles
        $stmt = $db->query("
            SELECT u.*, r.name as role_name 
            FROM users u 
            LEFT JOIN roles r ON u.role_id = r.id 
            ORDER BY u.id DESC
        ");
        $users = $stmt->fetchAll();
        
        $this->view('users.index', [
            'pageTitle' => 'Users Management',
            'users' => $users
        ]);
    }

    public function create() {
        Auth::enforce('user', 'create');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        $roles = $db->query("SELECT * FROM roles ORDER BY name ASC")->fetchAll();
        
        $this->view('users.create', [
            'pageTitle' => 'Add New User',
            'roles' => $roles
        ]);
    }

    public function store() {
        Auth::enforce('user', 'create');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullname = $_POST['fullname'];
            $email = $_POST['email'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $role_id = empty($_POST['role_id']) ? null : $_POST['role_id'];
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            $db = \Admin\Core\Database::getInstance()->getConnection();
            
            // Check if email exists
            $check = $db->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);
            if ($check->fetch()) {
                die("Email already exists!");
            }
            
            $stmt = $db->prepare("INSERT INTO users (fullname, email, password, role_id, is_active, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$fullname, $email, $password, $role_id, $is_active]);
            
            $userId = $db->lastInsertId();
            \Admin\Core\ActivityLogger::log('create', 'User', $userId, "Created user: $email");
            
            $this->redirect('/users');
        }
    }

    public function edit($id) {
        Auth::enforce('user', 'edit');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            die("User not found");
        }
        
        $roles = $db->query("SELECT * FROM roles ORDER BY name ASC")->fetchAll();
        
        $this->view('users.edit', [
            'pageTitle' => 'Edit User',
            'user' => $user,
            'roles' => $roles
        ]);
    }

    public function update($id) {
        Auth::enforce('user', 'edit');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $fullname = $_POST['fullname'];
            $email = $_POST['email'];
            $role_id = empty($_POST['role_id']) ? null : $_POST['role_id'];
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            $db = \Admin\Core\Database::getInstance()->getConnection();
            
            // Check if email exists for another user
            $check = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $check->execute([$email, $id]);
            if ($check->fetch()) {
                die("Email already used by another account!");
            }
            
            if (!empty($_POST['password'])) {
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE users SET fullname = ?, email = ?, password = ?, role_id = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$fullname, $email, $password, $role_id, $is_active, $id]);
            } else {
                $stmt = $db->prepare("UPDATE users SET fullname = ?, email = ?, role_id = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$fullname, $email, $role_id, $is_active, $id]);
            }
            
            \Admin\Core\ActivityLogger::log('update', 'User', $id, "Updated user: $email");
            
            $this->redirect('/users');
        }
    }

    public function delete($id) {
        Auth::enforce('user', 'delete');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        // Prevent deleting yourself
        if ($id == $_SESSION['user_id']) {
            die("You cannot delete your own account.");
        }
        
        $stmt = $db->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $email = $stmt->fetchColumn();
        
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        
        \Admin\Core\ActivityLogger::log('delete', 'User', $id, "Deleted user: $email");
        
        $this->redirect('/users');
    }
}

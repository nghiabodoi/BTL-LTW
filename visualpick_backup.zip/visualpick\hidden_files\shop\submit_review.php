<?php
session_start();
require_once '../db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) {
        die("Vui lòng đăng nhập để gửi đánh giá.");
    }
    
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $user_id = $_SESSION['user_id'];
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 5;
    $comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
    
    if ($product_id <= 0 || $rating < 1 || $rating > 5) {
        die("Dữ liệu không hợp lệ.");
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO product_reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
        $stmt->execute([$product_id, $user_id, $rating, $comment]);
        
        header("Location: product-detail.php?id=" . $product_id . "#reviews");
        exit;
    } catch (PDOException $e) {
        die("Lỗi: " . $e->getMessage());
    }
} else {
    header("Location: index.php");
    exit;
}
?>

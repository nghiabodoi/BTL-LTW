<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>Quản lý Người Dùng</h2>
    <a href="<?= BASE_URL ?>/users/create" class="btn btn-primary">+ Thêm Người Dùng</a>
</div>

<div class="card">
    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Họ và Tên</th>
                <th>Email</th>
                <th>Nhóm Quyền</th>
                <th>Trạng Thái</th>
                <th>Ngày Tạo</th>
                <th>Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($users) > 0): ?>
                <?php foreach($users as $user): ?>
                <tr>
                    <td><?= $user['id'] ?></td>
                    <td><?= htmlspecialchars($user['fullname']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= $user['role_name'] ? htmlspecialchars($user['role_name']) : 'Không có' ?></td>
                    <td>
                        <?php if($user['is_active']): ?>
                            <span style="color: #4CAF50; font-weight: bold;">Hoạt động</span>
                        <?php else: ?>
                            <span style="color: #F44336; font-weight: bold;">Đã khóa</span>
                        <?php endif; ?>
                    </td>
                    <td><?= date('Y-m-d H:i', strtotime($user['created_at'])) ?></td>
                    <td>
                        <a href="<?= BASE_URL ?>/users/edit/<?= $user['id'] ?>" class="btn btn-secondary btn-sm">Sửa</a>
                        <form action="<?= BASE_URL ?>/users/delete/<?= $user['id'] ?>" method="POST" style="display:inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa người dùng này?');">
                            <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" style="text-align: center;">Chưa có người dùng nào.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php
session_start();
$order = $_SESSION['last_order'] ?? null;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt hàng thành công - VISU∀L PICK</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .success-container {
            text-align: center;
            padding: 100px 0;
            max-width: 600px;
            margin: 0 auto;
        }
        .success-icon {
            font-size: 80px;
            color: #fff;
            margin-bottom: 30px;
        }
        .order-details {
            background: #0a0a0a;
            padding: 40px;
            border: 1px solid #222;
            text-align: left;
            margin-top: 40px;
        }
        .order-details h3 {
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
            font-size: 14px;
            color: #888;
        }
        .detail-row span:last-child {
            color: #fff;
        }
    </style>
</head>
<body>

    <header class="header">
        <div class="container" style="text-align: center; padding: 20px 0;">
            <div class="logo"><a href="index.php">VISU∀L PICK</a></div>
        </div>
    </header>

    <div class="container success-container">
        <div class="success-icon">✓</div>
        <h1>ĐẶT HÀNG THÀNH CÔNG</h1>
        <p style="color: #888; margin-top: 20px;">Cảm ơn bạn đã tin tưởng VISU∀L PICK. Đơn hàng của bạn đang được xử lý.</p>

        <?php if ($order): ?>
        <div class="order-details">
            <h3>Thông tin đơn hàng</h3>
            <div class="detail-row">
                <span>Khách hàng:</span>
                <span><?php echo htmlspecialchars($order['fullname'] ?? ''); ?></span>
            </div>
            <div class="detail-row">
                <span>Số điện thoại:</span>
                <span><?php echo htmlspecialchars($order['phone'] ?? ''); ?></span>
            </div>
            <div class="detail-row">
                <span>Địa chỉ:</span>
                <span><?php echo htmlspecialchars($order['address'] ?? ''); ?></span>
            </div>
            <div class="detail-row">
                <span>Ngày đặt:</span>
                <span><?php echo htmlspecialchars($order['date'] ?? ''); ?></span>
            </div>
        </div>
        <?php endif; ?>

        <div style="margin-top: 50px;">
            <a href="index.php" class="btn-primary">TIẾP TỤC MUA SẮM</a>
        </div>
    </div>

</body>
</html>

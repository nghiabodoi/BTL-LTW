<?php
ob_start();
require_once __DIR__ . '/db_config.php';

// Mock Auth
class Auth {
    public static function enforce() {}
}
namespace Admin\Core {
    class Controller {
        public function view($name, $data) {
            extract($data);
            require __DIR__ . '/../admin/views/dashboard/index.php';
        }
    }
    class Database {
        private static $instance;
        public $conn;
        public static function getInstance() {
            if (!self::$instance) {
                self::$instance = new self();
                global $pdo;
                self::$instance->conn = $pdo;
            }
            return self::$instance;
        }
        public function getConnection() { return $this->conn; }
    }
}

namespace Admin\Controllers {
    use Admin\Core\Controller;
    use Admin\Core\Database;

    class DashboardController extends Controller {
        public function index() {
            $db = Database::getInstance()->getConnection();
            $usersCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
            $ordersCount = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
            $productsCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
            $recentOrders = $db->query("SELECT * FROM orders ORDER BY order_date DESC LIMIT 5")->fetchAll();
            
            $revenueData = $db->query("
                SELECT DATE_FORMAT(order_date, '%b') as month_name, SUM(total_money) as revenue 
                FROM orders 
                WHERE status = 'delivered' AND order_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH) 
                GROUP BY DATE_FORMAT(order_date, '%Y-%m'), DATE_FORMAT(order_date, '%b') 
                ORDER BY DATE_FORMAT(order_date, '%Y-%m') ASC
            ")->fetchAll(\PDO::FETCH_ASSOC);

            $statusData = $db->query("
                SELECT status, COUNT(*) as count 
                FROM orders 
                GROUP BY status
            ")->fetchAll(\PDO::FETCH_ASSOC);
            
            $this->view('dashboard.index', [
                'pageTitle' => 'Bảng điều khiển',
                'usersCount' => $usersCount,
                'ordersCount' => $ordersCount,
                'productsCount' => $productsCount,
                'recentOrders' => $recentOrders,
                'revenueData' => $revenueData,
                'statusData' => $statusData
            ]);
        }
    }

    $controller = new DashboardController();
    $controller->index();
}
$output = ob_get_clean();
file_put_contents('dashboard_output.html', $output);
echo "Done";

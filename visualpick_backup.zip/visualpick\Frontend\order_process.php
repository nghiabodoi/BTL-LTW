<?php
session_start();
require_once __DIR__ . '/../db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        header("Location: cart.php");
        exit;
    }

    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0; // 0 for guest if your DB allows, otherwise you might need to enforce login. Let's assume DB allows NULL or 0, or we must enforce login. Wait, the DB users table has no 'guest'.
    // Let's enforce login for checkout to be safe with user_id, or just use NULL if user_id allows NULL. The schema says user_id INT, doesn't say NOT NULL. We will use NULL if not logged in.
    
    $fullname = $_POST['fullname'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $district = $_POST['district'] ?? '';
    $full_address = "$address, $district, $city";
    
    $total_money = $_SESSION['cart_total'] ?? 0;
    $payment_method = $_POST['payment_method'] ?? 'cod';
    $status = 'pending';
    
    try {
        $pdo->beginTransaction();
        
        // --- DEADLOCK PREVENTION & ROW-LEVEL LOCKING ---
        // Sort product IDs from smallest to largest to prevent Deadlocks
        $product_ids = array_keys($_SESSION['cart']);
        sort($product_ids);
        
        // Build placeholders for the IN clause
        $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
        
        // SELECT ... FOR UPDATE to lock the rows
        $stmt_lock = $pdo->prepare("SELECT id, price, stock FROM products WHERE id IN ($placeholders) FOR UPDATE");
        $stmt_lock->execute($product_ids);
        
        $products_locked = [];
        while ($row = $stmt_lock->fetch()) {
            $products_locked[$row['id']] = $row;
        }
        // -----------------------------------------------

        // Insert order
        $stmt = $pdo->prepare("
            INSERT INTO orders (user_id, order_date, total_money, status, fullname, phone_number, address, payment_method, active)
            VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, 1)
        ");
        $stmt->execute([
            $user_id ? $user_id : null,
            $total_money,
            $status,
            $fullname,
            $phone,
            $full_address,
            $payment_method
        ]);
        
        $order_id = $pdo->lastInsertId();
        
        // Insert order details
        $stmt_detail = $pdo->prepare("
            INSERT INTO order_details (order_id, product_id, quantity, price)
            VALUES (?, ?, ?, ?)
        ");
        
        foreach ($_SESSION['cart'] as $product_id => $qty) {
            // Price is retrieved from the locked row, ensuring accuracy
            $price = $products_locked[$product_id]['price'] ?? 0;
            
            // Note: We don't check stock here in PHP, the Trigger 'prevent_overselling' 
            // will catch it and throw a PDOException (SQLSTATE 45000) if $qty > stock.
            $stmt_detail->execute([$order_id, $product_id, $qty, $price]);
        }
        
        $pdo->commit();
        
        $_SESSION['last_order'] = [
            'id' => $order_id,
            'fullname' => $fullname,
            'email' => $email,
            'phone' => $phone,
            'address' => $full_address,
            'total' => $total_money,
            'date' => date('d/m/Y H:i')
        ];
        
        // Clear cart
        unset($_SESSION['cart']);
        unset($_SESSION['cart_total']);
        
        header("Location: order_success.php");
        exit;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        
        // Check if the exception is from our custom Trigger (SQLSTATE 45000)
        if ($e->getCode() == '45000') {
            die("<div style='text-align:center; margin-top:50px; font-family:sans-serif;'><h2>Rất tiếc! Đặt hàng thất bại.</h2><p>" . $e->getMessage() . "</p><a href='cart.php'>Quay lại giỏ hàng</a></div>");
        }
        
        die("Có lỗi xảy ra khi đặt hàng: " . $e->getMessage());
    }

} else {
    header("Location: index.php");
    exit;
}
?>


<?php
namespace Admin\Controllers;

use Admin\Core\Controller;
use Admin\Core\Auth;

class TicketController extends Controller {
    public function index() {
        Auth::enforce('ticket', 'view');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        $tickets = $db->query("SELECT t.*, u.fullname as customer_name FROM tickets t JOIN users u ON t.user_id = u.id ORDER BY t.updated_at DESC")->fetchAll();
        
        $this->view('tickets.index', [
            'pageTitle' => 'Hỗ trợ Khách hàng (Tickets)',
            'tickets' => $tickets
        ]);
    }

    public function show($id) {
        Auth::enforce('ticket', 'view');
        
        $db = \Admin\Core\Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT t.*, u.fullname as customer_name, u.email FROM tickets t JOIN users u ON t.user_id = u.id WHERE t.id = ?");
        $stmt->execute([$id]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            die("Ticket not found.");
        }
        
        $msgStmt = $db->prepare("SELECT m.*, u.fullname as sender_name FROM ticket_messages m JOIN users u ON m.user_id = u.id WHERE m.ticket_id = ? ORDER BY m.created_at ASC");
        $msgStmt->execute([$id]);
        $messages = $msgStmt->fetchAll();
        
        $this->view('tickets.show', [
            'pageTitle' => 'Chi tiết Ticket #' . $id,
            'ticket' => $ticket,
            'messages' => $messages
        ]);
    }

    public function reply($id) {
        Auth::enforce('ticket', 'edit');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $message = $_POST['message'] ?? '';
            if (!empty(trim($message))) {
                $db = \Admin\Core\Database::getInstance()->getConnection();
                $stmt = $db->prepare("INSERT INTO ticket_messages (ticket_id, user_id, message, is_admin) VALUES (?, ?, ?, 1)");
                $stmt->execute([
                    $id,
                    $_SESSION['user_id'],
                    trim($message)
                ]);
                
                // Update ticket updated_at
                $db->prepare("UPDATE tickets SET updated_at = NOW() WHERE id = ?")->execute([$id]);
            }
        }
        $this->redirect('/tickets/show/' . $id);
    }

    public function updateStatus($id) {
        Auth::enforce('ticket', 'edit');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $status = $_POST['status'] ?? 'open';
            $db = \Admin\Core\Database::getInstance()->getConnection();
            $stmt = $db->prepare("UPDATE tickets SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
        }
        $this->redirect('/tickets/show/' . $id);
    }
}

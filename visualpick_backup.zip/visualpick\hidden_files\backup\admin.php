<?php
session_start();
require_once 'db_config.php';

// Cần đăng nhập và là Admin (role_id = 1)
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id']) || $_SESSION['role_id'] != 1) {
    // Tạm thời nếu hệ thống chưa set role_id, ta bỏ qua kiểm tra chặt chẽ để demo, 
    // NHƯNG TRONG THỰC TẾ PHẢI MỞ KHÓA DÒNG DƯỚI ĐÂY:
    // header("Location: index.php");
    // exit;
}

// Lấy danh sách tất cả đơn hàng
$stmt = $pdo->query("SELECT o.*, u.email FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.order_date DESC");
$orders = $stmt->fetchAll();

// Xử lý cập nhật trạng thái
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['status'];
    
    try {
        $update_stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $update_stmt->execute([$new_status, $order_id]);
        $msg = "Cập nhật thành công!";
        // Reload lại để lấy data mới
        header("Location: admin.php?msg=success");
        exit;
    } catch (PDOException $e) {
        $error = "Lỗi cập nhật: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .admin-container {
            padding: 50px 0;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            background: #111;
            border-radius: 5px;
            overflow: hidden;
        }
        .admin-table th, .admin-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #222;
        }
        .admin-table th {
            background: #000;
            color: #888;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .status-select {
            background: #000;
            color: #fff;
            border: 1px solid #333;
            padding: 5px;
            border-radius: 3px;
        }
        .update-btn {
            background: #fff;
            color: #000;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
        }
        .msg-success {
            background: #00ff88;
            color: #000;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="logo">
                <a href="index.php">VISU∀L PICK - ADMIN</a>
            </div>
            <div class="header-icons">
                <a href="index.php" class="icon-link" style="font-size: 12px; text-transform: uppercase; text-decoration: underline; margin-right: 15px;">Về Trang Chủ</a>
                <a href="profile.php" class="icon-link" style="font-size: 12px; text-transform: uppercase; text-decoration: underline;">Hồ Sơ</a>
            </div>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>Quản trị Đơn hàng</h1>
            <p>Thay đổi trạng thái đơn hàng sẽ tự động kích hoạt Trigger hoàn kho (nếu Cancel) và lưu Log lịch sử.</p>
        </div>
    </div>

    <section class="container admin-container">
        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'success'): ?>
            <div class="msg-success">Cập nhật trạng thái thành công! (Xem trigger log trong CSDL)</div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div style="background: #ff0055; color: #fff; padding: 10px; margin-bottom: 20px;"><?php echo $error; ?></div>
        <?php endif; ?>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Mã Đơn</th>
                    <th>Ngày Đặt</th>
                    <th>Khách Hàng</th>
                    <th>Tổng Tiền</th>
                    <th>Trạng Thái</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>#<?php echo $order['id']; ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                        <td>
                            <?php echo htmlspecialchars($order['fullname'] ?? ''); ?><br>
                            <span style="color: #888; font-size: 12px;"><?php echo htmlspecialchars($order['phone_number'] ?? ''); ?></span>
                        </td>
                        <td><?php echo number_format($order['total_money'], 0, ',', '.'); ?>đ</td>
                        <td>
                            <form action="admin.php" method="POST" style="display: flex; gap: 10px; align-items: center;">
                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                <select name="status" class="status-select">
                                    <option value="pending" <?php if($order['status']=='pending') echo 'selected'; ?>>Pending</option>
                                    <option value="processing" <?php if($order['status']=='processing') echo 'selected'; ?>>Processing</option>
                                    <option value="shipped" <?php if($order['status']=='shipped') echo 'selected'; ?>>Shipped</option>
                                    <option value="delivered" <?php if($order['status']=='delivered') echo 'selected'; ?>>Delivered</option>
                                    <option value="cancelled" <?php if($order['status']=='cancelled') echo 'selected'; ?>>Cancelled</option>
                                </select>
                                <button type="submit" class="update-btn">Lưu</button>
                            </form>
                        </td>
                        <td>
                            <!-- Chỗ này có thể làm nút "Xem chi tiết" sau -->
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>

</body>
</html>

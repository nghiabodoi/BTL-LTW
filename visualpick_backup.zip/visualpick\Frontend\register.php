<?php
require_once __DIR__ . '/../db_config.php';

$message = "";

// Xử lý khi người dùng nhấn nút Đăng ký
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy dữ liệu từ form
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $plain_password = $_POST['password'];

    // 1. Kiểm tra cơ bản
    if (empty($fullname) || empty($email) || empty($plain_password)) {
        $message = "<p style='color: #ff4d4d;'>Vui lòng nhập đầy đủ thông tin!</p>";
    } else {
        // 2. Mã hóa mật khẩu
        $hashed_password = password_hash($plain_password, PASSWORD_BCRYPT);
        $role_id = 2; // Mặc định là khách hàng (Customer)
        $is_active = 1;

        try {
            // 3. Chuẩn bị câu lệnh SQL (Prepared Statement) để chống SQL Injection
            $sql = "INSERT INTO users (fullname, email, password, role_id, is_active) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            
            // 4. Thực thi
            $stmt->execute([$fullname, $email, $hashed_password, $role_id, $is_active]);
            
            $message = "<p style='color: #4ade80;'>Đăng ký thành công! <a href='login.php' style='color: #ffffff; font-weight: bold; text-decoration: underline;'>Đăng nhập ngay</a></p>";
        } catch (PDOException $e) {
            // Kiểm tra mã lỗi MySQL
            if ($e->errorInfo[1] == 1062) {
                $message = "<p style='color: #ff4d4d;'>Lỗi: Email này đã tồn tại trong hệ thống!</p>";
            } else {
                // Hiển thị lỗi chi tiết (ví dụ: lỗi role_id không tồn tại) để Nghĩa dễ sửa
                $message = "<p style='color: #ff4d4d;'>Lỗi hệ thống: " . $e->getMessage() . "</p>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <a href="#" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="auth-section">
        <div class="auth-box">
            <h2>Tạo tài khoản mới</h2>
            <p>Tham gia cộng đồng thời trang âm nhạc cùng Nghĩa</p>
            
            <div class="alert-box">
                <?php echo $message; ?>
            </div>

            <form action="register.php" method="POST">
                <div class="input-group">
                    <label>Họ và tên</label>
                    <input type="text" name="fullname" placeholder="Ví dụ: Đinh Đức Nghĩa" required 
                           value="<?php echo isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : ''; ?>">
                </div>
                
                <div class="input-group">
                    <label>Email đăng ký</label>
                    <input type="email" name="email" placeholder="nghia@example.com" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                
                <div class="input-group">
                    <label>Mật khẩu</label>
                    <input type="password" name="password" placeholder="Tối thiểu 6 ký tự" required>
                </div>
                
                <button type="submit" class="btn-primary auth-btn">Xác nhận đăng ký</button>
            </form>
            
            <div class="auth-switch">
                Đã có tài khoản? <a href="login.php">Quay lại Đăng nhập</a>
            </div>
        </div>
    </section>

</body>
</html>


<?php
require 'db_config.php';

$tables = [];
$stmt = $pdo->query("SHOW TABLES");
while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
    $tables[] = $row[0];
}

$sql = "-- VisualPick Database Dump\n\n";

foreach ($tables as $table) {
    $stmt = $pdo->query("SHOW CREATE TABLE $table");
    $row = $stmt->fetch(PDO::FETCH_NUM);
    $sql .= "DROP TABLE IF EXISTS `$table`;\n";
    $sql .= $row[1] . ";\n\n";

    $stmt = $pdo->query("SELECT * FROM $table");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $keys = array_keys($row);
        $values = array_values($row);
        
        $escapedValues = array_map(function($val) use ($pdo) {
            if ($val === null) return 'NULL';
            return $pdo->quote($val);
        }, $values);

        $sql .= "INSERT INTO `$table` (`" . implode("`, `", $keys) . "`) VALUES (" . implode(", ", $escapedValues) . ");\n";
    }
    $sql .= "\n";
}

file_put_contents('visualpick.sql', $sql);
echo "Database dumped successfully to visualpick.sql";

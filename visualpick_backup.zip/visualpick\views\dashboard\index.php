<div class="grid">
    <div class="card" style="border-left: 4px solid var(--primary);">
        <div class="card-title">Tổng Người Dùng</div>
        <div class="card-value"><?php echo $usersCount; ?></div>
    </div>
    <div class="card" style="border-left: 4px solid #f59e0b;">
        <div class="card-title">Tổng Đơn Hàng</div>
        <div class="card-value"><?php echo $ordersCount; ?></div>
    </div>
    <div class="card" style="border-left: 4px solid #10b981;">
        <div class="card-title">Tổng Sản Phẩm</div>
        <div class="card-value"><?php echo $productsCount; ?></div>
    </div>
    <div class="card" style="border-left: 4px solid #8b5cf6;">
        <div class="card-title">Doanh Thu (Tr)</div>
        <div class="card-value">
            <?php 
            $db = \Admin\Core\Database::getInstance()->getConnection();
            $rev = $db->query("SELECT SUM(total_money) FROM orders WHERE status = 'delivered'")->fetchColumn();
            echo $rev ? number_format($rev / 1000000, 2) . ' Tr' : '0';
            ?>
        </div>
    </div>
</div>

<div class="grid" style="grid-template-columns: 2fr 1fr;">
    <!-- Line Chart for Revenue -->
    <div class="card">
        <div class="card-title" style="margin-bottom: 20px;">Doanh Thu 6 Tháng Gần Nhất</div>
        <div style="position: relative; height: 300px; width: 100%;">
            <canvas id="revenueChart"></canvas>
        </div>
    </div>
    
    <!-- Pie Chart for Order Status -->
    <div class="card">
        <div class="card-title" style="margin-bottom: 20px;">Trạng Thái Đơn Hàng</div>
        <div style="position: relative; height: 300px; width: 100%;">
            <canvas id="statusChart"></canvas>
        </div>
    </div>
</div>

<div class="card" style="margin-bottom: 30px;">
    <div class="card-title" style="margin-bottom: 20px;">Đơn Hàng Gần Đây</div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Mã Đơn</th>
                    <th>Khách Hàng</th>
                    <th>Ngày Đặt</th>
                    <th>Trạng Thái</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($recentOrders as $order): ?>
                    <tr>
                        <td style="font-weight: 500;">#<?php echo $order['id']; ?></td>
                        <td><?php echo htmlspecialchars($order['fullname']); ?></td>
                        <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                        <td>
                            <?php
                                $statusColors = [
                                    'pending' => 'pending',
                                    'processing' => 'primary',
                                    'shipped' => 'primary',
                                    'delivered' => 'completed',
                                    'cancelled' => 'cancelled'
                                ];
                                $class = $statusColors[$order['status']] ?? '';
                                $statusMap = [
                                    'pending' => 'Chờ xử lý',
                                    'processing' => 'Đang chuẩn bị',
                                    'shipped' => 'Đang giao',
                                    'delivered' => 'Đã giao',
                                    'cancelled' => 'Đã hủy'
                                ];
                            ?>
                            <span class="badge <?php echo $class; ?>">
                                <?php echo $statusMap[$order['status']] ?? ucfirst($order['status']); ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if(empty($recentOrders)): ?>
                    <tr><td colspan="4" style="text-align: center; color: var(--text-muted);">Chưa có đơn hàng nào.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
// Prepare data for JS
$revLabels = [];
$revData = [];
foreach ($revenueData as $row) {
    $revLabels[] = $row['month_name'];
    $revData[] = $row['revenue'] / 1000000; // in Millions
}

$statusLabels = [];
$statusCounts = [];
$statusColors = [];
$colorMap = [
    'pending' => '#f59e0b',
    'processing' => '#3b82f6',
    'shipped' => '#8b5cf6',
    'delivered' => '#10b981',
    'cancelled' => '#ef4444'
];
$labelMap = [
    'pending' => 'Chờ xử lý',
    'processing' => 'Đang chuẩn bị',
    'shipped' => 'Đang giao',
    'delivered' => 'Đã giao',
    'cancelled' => 'Đã hủy'
];
foreach ($statusData as $row) {
    $statusLabels[] = $labelMap[$row['status']] ?? ucfirst($row['status']);
    $statusCounts[] = $row['count'];
    $statusColors[] = $colorMap[$row['status']] ?? '#cccccc';
}
?>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Chart Defaults
    Chart.defaults.color = '#8b8d96';
    Chart.defaults.font.family = "'Inter', sans-serif";

    // 1. Revenue Line Chart
    const ctxLine = document.getElementById('revenueChart').getContext('2d');
    
    // Gradient fill for line chart
    let gradientLine = ctxLine.createLinearGradient(0, 0, 0, 400);
    gradientLine.addColorStop(0, 'rgba(59, 130, 246, 0.4)');
    gradientLine.addColorStop(1, 'rgba(59, 130, 246, 0.0)');

    new Chart(ctxLine, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revLabels); ?>,
            datasets: [{
                label: 'Doanh thu (Triệu VNĐ)',
                data: <?php echo json_encode($revData); ?>,
                borderColor: '#3b82f6',
                backgroundColor: gradientLine,
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#3b82f6',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: '#3b82f6',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(255, 255, 255, 0.05)', borderDash: [5, 5] },
                    ticks: { callback: function(value) { return value + ' Tr'; } }
                },
                x: {
                    grid: { display: false }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1a1d24',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#2a2e37',
                    borderWidth: 1,
                    padding: 10,
                    callbacks: {
                        label: function(context) {
                            return context.raw.toFixed(2) + ' Triệu VNĐ';
                        }
                    }
                }
            }
        }
    });

    // 2. Order Status Doughnut Chart
    const ctxPie = document.getElementById('statusChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($statusLabels); ?>,
            datasets: [{
                data: <?php echo json_encode($statusCounts); ?>,
                backgroundColor: <?php echo json_encode($statusColors); ?>,
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, usePointStyle: true, pointStyle: 'circle' }
                },
                tooltip: {
                    backgroundColor: '#1a1d24',
                    borderColor: '#2a2e37',
                    borderWidth: 1,
                    padding: 10
                }
            }
        }
    });
});
</script>

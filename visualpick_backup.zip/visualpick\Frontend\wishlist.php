<?php
session_start();
require_once __DIR__ . '/../db_config.php';

$products = [];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    try {
        $stmt = $pdo->prepare("
            SELECT p.* FROM products p
            JOIN wishlists w ON p.id = w.product_id
            WHERE w.user_id = ? AND p.is_active = 1
            ORDER BY w.created_at DESC
        ");
        $stmt->execute([$user_id]);
        $products = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = $e->getMessage();
    }
} else {
    $error = "Vui lòng đăng nhập để xem danh sách yêu thích.";
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách yêu thích - VISU∀L PICK</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .wishlist-empty {
            text-align: center;
            padding: 100px 0;
            color: #888;
        }
        .heart-icon.active {
            color: #ff0055 !important;
        }
    </style>
</head>
<body>

    <header class="header two-tier-header">
        <div class="header-top container">
            <div class="header-left"></div>
            <div class="logo">
                <a href="index.php">VISU∀L PICK</a>
            </div>
            <div class="header-icons">
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="q" placeholder="Tìm kiếm sản phẩm..." class="search-input">
                    <button type="submit" class="search-btn">
                        <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                </form>
                
                <?php if (isset($_SESSION['user_fullname'])): ?>
                    <div style="display: flex; align-items: center; gap: 10px; color: #fff; font-size: 11px; margin: 0 10px; text-transform: uppercase; letter-spacing: 1px;">
                        <span><?php echo htmlspecialchars($_SESSION['user_fullname']); ?></span>
                        <?php if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 1): ?><a href="../" style="color: #f39c12; text-decoration: underline; margin-right: 10px;">Admin Panel</a><?php endif; ?><a href="logout.php" style="color: #888; text-decoration: underline;">Thoát</a>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="icon-link"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg></a>
                <?php endif; ?>
                
                <a href="wishlist.php" class="icon-link"><svg width="22" height="22" fill="currentColor" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg></a>
                <a href="cart.php" class="icon-link cart-icon">
                    <svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span class="cart-badge">0</span>
                </a>
            </div>
        </div>
        <div class="header-bottom container">
            <nav class="main-menu">
                <ul>
                    <li><a href="kpop.php">Kpop outfit</a></li>
                    <li><a href="usuk.php">US-UK outfit</a></li>
                    <li><a href="vpop.php">Vpop outfit</a></li>
                    <li><a href="lookbook.php">Artist Lookbook</a></li>
                    <li><a href="contact.php">Liên hệ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="page-header">
        <div class="container">
            <h1>DANH SÁCH YÊU THÍCH</h1>
            <p><a href="index.php">Trang chủ</a> / Yêu thích</p>
        </div>
    </div>

    <section class="shop-page">
        <div class="container">
            <main class="main-content">
                <div class="products-grid-inner">
                    <?php if (isset($error) && !isset($_SESSION['user_id'])): ?>
                        <div class="wishlist-empty" style="grid-column: 1/-1;">
                            <p><?php echo $error; ?></p>
                            <a href="login.php" class="btn-primary" style="margin-top: 20px;">Đăng nhập ngay</a>
                        </div>
                    <?php elseif (count($products) > 0): ?>
                        <?php foreach ($products as $item): ?>
                        <div class="product-card" id="wishlist-item-<?php echo $item['id']; ?>">
                            <a href="product-detail.php?id=<?php echo $item['id']; ?>" style="display: block; text-decoration: none; color: inherit;">
                                <div class="product-img-box">
                                    <div class="heart-icon active" onclick="toggleWishlist(event, <?php echo $item['id']; ?>)">♥</div>
                                    <?php if (!empty($item['label'])): ?>
                                        <div class="badge"><?php echo htmlspecialchars($item['label'] ?? ''); ?></div>
                                    <?php endif; ?>
                                    <img src="<?php echo filter_var($item['image_url'], FILTER_VALIDATE_URL) ? htmlspecialchars($item['image_url']) : '../assets/uploads/' . basename($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" onerror="this.src='https://via.placeholder.com/300x400/0a0a0a/fff?text=CHÈN+ẢNH'">
                                </div>
                                <div class="product-info">
                                    <p class="brand"><?php echo htmlspecialchars($item['brand'] ?? ''); ?></p>
                                    <h3 class="product-title"><?php echo htmlspecialchars($item['name']); ?></h3>
                                    <p class="product-price"><?php echo number_format($item['price'], 0, ',', '.'); ?> VND</p>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="wishlist-empty" style="grid-column: 1/-1;">
                            <p>Danh sách yêu thích của bạn đang trống.</p>
                            <a href="index.php" class="btn-primary" style="margin-top: 20px;">Tiếp tục mua sắm</a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </section>

    <script>
        function toggleWishlist(event, productId) {
            event.preventDefault();
            event.stopPropagation();
            
            fetch('toggle_wishlist.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'unauthorized') {
                    alert(data.message);
                    window.location.href = 'login.php';
                    return;
                }
                
                if (data.status === 'removed') {
                    const item = document.getElementById('wishlist-item-' + productId);
                    if (item) {
                        item.style.opacity = '0';
                        setTimeout(() => {
                            item.remove();
                            if (document.querySelectorAll('.product-card').length === 0) {
                                location.reload();
                            }
                        }, 300);
                    }
                }
            });
        }
    </script>

</body>
</html>


<?php
namespace Admin\Core;

class Controller {
    protected function view($view, $data = [], $useLayout = true) {
        // Extract data to variables
        extract($data);
        
        $viewFile = __DIR__ . "/../views/" . str_replace('.', '/', $view) . ".php";
        
        if (file_exists($viewFile)) {
            if ($useLayout) {
                ob_start();
                require_once $viewFile;
                $content = ob_get_clean();
                
                // Allow view to override page title
                $pageTitle = $data['pageTitle'] ?? 'Dashboard';
                
                // Require layout
                require_once __DIR__ . "/../views/layouts/main.php";
            } else {
                require_once $viewFile;
            }
        } else {
            die("View $viewFile does not exist.");
        }
    }

    protected function redirect($url) {
        $baseUrl = defined('BASE_URL') ? BASE_URL : '';
        header("Location: " . $baseUrl . $url);
        exit;
    }

    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}
